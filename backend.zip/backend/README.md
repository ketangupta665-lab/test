# single-backend

This is a simple monolithic Spring Boot backend combining basic features (users, orders, invoices, payments) for testing and local development.

Run locally:

```bash
cd "c:\Users\ketan\Music\new workspace\single-backend"
mvn package
java -jar target/single-backend-0.0.1-SNAPSHOT.jar
```

H2 console: http://localhost:8081/h2-console
