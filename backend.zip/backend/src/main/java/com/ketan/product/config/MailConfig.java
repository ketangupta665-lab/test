package com.ketan.product.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import java.util.Properties;

@Configuration
public class MailConfig {
    @Value("${ses.smtp.host:}")
    private String host;

    @Value("${ses.smtp.port:587}")
    private int port;

    @Value("${ses.smtp.username:}")
    private String username;

    @Value("${ses.smtp.password:}")
    private String password;

    @Value("${ses.smtp.auth:true}")
    private boolean auth;

    @Value("${ses.smtp.starttls.enable:true}")
    private boolean starttls;

    @Bean
    public JavaMailSender javaMailSender() {
        if (host == null || host.isBlank() || username == null || username.isBlank() || password == null || password.isBlank()) {
            return null; // not configured, let EmailService fallback
        }
        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
        mailSender.setHost(host);
        mailSender.setPort(port);
        mailSender.setUsername(username);
        mailSender.setPassword(password);

        Properties props = mailSender.getJavaMailProperties();
        props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.auth", String.valueOf(auth));
        props.put("mail.smtp.starttls.enable", String.valueOf(starttls));
        props.put("mail.debug", "false");

        return mailSender;
    }
}
