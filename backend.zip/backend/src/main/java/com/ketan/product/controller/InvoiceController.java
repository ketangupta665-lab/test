package com.ketan.product.controller;

import com.ketan.product.exception.ResourceNotFoundException;
import com.ketan.product.model.Invoice;
import com.ketan.product.repository.InvoiceRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/invoices")
public class InvoiceController {
    private final InvoiceRepository repo;

    public InvoiceController(InvoiceRepository repo) { this.repo = repo; }

    @GetMapping
    public List<Invoice> all() { return repo.findAll(); }

    @GetMapping("/{id}")
    public ResponseEntity<Invoice> get(@PathVariable Long id) {
        Invoice invoice = repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Invoice", "id", id));
        return ResponseEntity.ok(invoice);
    }

    @PostMapping
    public Invoice create(@RequestBody Invoice invoice) { return repo.save(invoice); }
}
