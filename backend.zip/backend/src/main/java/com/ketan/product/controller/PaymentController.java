package com.ketan.product.controller;

import com.ketan.product.exception.BadRequestException;
import com.ketan.product.exception.PaymentException;
import com.ketan.product.exception.ResourceNotFoundException;
import com.ketan.product.model.OrderEntity;
import com.ketan.product.model.Payment;
import com.ketan.product.model.User;
import com.ketan.product.repository.OrderRepository;
import com.ketan.product.repository.PaymentRepository;
import com.ketan.product.repository.UserRepository;
import com.ketan.product.service.RazorpayService;
import com.razorpay.RazorpayException;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    private static final Logger log = LoggerFactory.getLogger(PaymentController.class);

    private final PaymentRepository paymentRepo;
    private final OrderRepository orderRepo;
    private final UserRepository userRepo;
    private final RazorpayService razorpayService;

    public PaymentController(PaymentRepository paymentRepo, OrderRepository orderRepo,
                             UserRepository userRepo, RazorpayService razorpayService) {
        this.paymentRepo = paymentRepo;
        this.orderRepo = orderRepo;
        this.userRepo = userRepo;
        this.razorpayService = razorpayService;
    }

    // ---- Public: return Razorpay key-id to frontend ----
    @GetMapping("/razorpay-key")
    public Map<String, String> getRazorpayKey() {
        Map<String, String> m = new HashMap<>();
        m.put("key", razorpayService.getKeyId());
        return m;
    }

    // ---- Create Razorpay order for a given app order ----
    @PostMapping("/create-order/{orderId}")
    public ResponseEntity<?> createRazorpayOrder(@PathVariable Long orderId,
                                                  Authentication auth,
                                                  HttpServletRequest request) {
        OrderEntity order = orderRepo.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order", "id", orderId));

        BigDecimal amount = order.getAmount();
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0)
            throw new BadRequestException("Order amount must be greater than zero");

        try {
            Map<String, Object> rzpOrder = razorpayService.createOrder(amount, "INR", "order_" + orderId);

            // Save/update payment record with razorpay order id
            Payment payment = paymentRepo.findByOrderId(orderId).orElse(new Payment());
            payment.setOrderId(orderId);
            payment.setAmount(amount);
            payment.setCurrency("INR");
            payment.setRazorpayOrderId((String) rzpOrder.get("id"));
            payment.setStatus("CREATED");

            // Capture user & client info
            if (auth != null) {
                payment.setUsername(auth.getName());
                userRepo.findByEmail(auth.getName()).ifPresent(u -> payment.setUserId(u.getId()));
            }
            payment.setIpAddress(resolveClientIp(request));
            payment.setUserAgent(request.getHeader("User-Agent"));

            paymentRepo.save(payment);

            // Update order payment status
            order.setPaymentStatus("CREATED");
            orderRepo.save(order);

            Map<String, Object> resp = new HashMap<>(rzpOrder);
            resp.put("key", razorpayService.getKeyId());
            resp.put("appOrderId", orderId);
            resp.put("paymentId", payment.getId());
            return ResponseEntity.ok(resp);

        } catch (RazorpayException e) {
            throw new PaymentException("Razorpay order creation failed: " + e.getMessage(), e);
        }
    }

    // ---- Verify payment after Razorpay checkout ----
    @PostMapping("/verify")
    public ResponseEntity<?> verifyPayment(@RequestBody Map<String, String> payload,
                                            HttpServletRequest request) {
        String razorpayOrderId = payload.get("razorpay_order_id");
        String razorpayPaymentId = payload.get("razorpay_payment_id");
        String razorpaySignature = payload.get("razorpay_signature");

        if (razorpayOrderId == null || razorpayPaymentId == null || razorpaySignature == null) {
            throw new BadRequestException("Missing payment verification fields: razorpay_order_id, razorpay_payment_id and razorpay_signature are all required");
        }

        boolean valid = razorpayService.verifySignature(razorpayOrderId, razorpayPaymentId, razorpaySignature);

        Payment payment = paymentRepo.findByRazorpayOrderId(razorpayOrderId)
                .orElseThrow(() -> new ResourceNotFoundException("Payment", "razorpayOrderId", razorpayOrderId));

        if (valid) {
            payment.setRazorpayPaymentId(razorpayPaymentId);
            payment.setRazorpaySignature(razorpaySignature);
            payment.setStatus("PAID");
            payment.setPaidAt(LocalDateTime.now());

            // Fetch full payment details from Razorpay (UTR, method, bank, card, fee, etc.)
            try {
                Map<String, Object> details = razorpayService.fetchPaymentDetails(razorpayPaymentId);

                payment.setMethod((String) details.get("method"));
                payment.setBank((String) details.get("bank"));
                payment.setWallet((String) details.get("wallet"));
                payment.setVpa((String) details.get("vpa"));
                payment.setPayerEmail((String) details.get("email"));
                payment.setPayerContact((String) details.get("contact"));
                payment.setRazorpayFee((Integer) details.get("fee"));
                payment.setRazorpayTax((Integer) details.get("tax"));
                payment.setInternational((Boolean) details.get("international"));

                // Card details
                payment.setCardId((String) details.get("card_id"));
                payment.setCardLast4((String) details.get("card_last4"));
                payment.setCardNetwork((String) details.get("card_network"));
                payment.setCardType((String) details.get("card_type"));

                // Transaction references (UTR, RRN, auth code)
                payment.setUtr((String) details.get("utr"));
                payment.setRrn((String) details.get("rrn"));
                payment.setAuthCode((String) details.get("auth_code"));

            } catch (RazorpayException e) {
                log.warn("Could not fetch payment details from Razorpay for {}: {}", razorpayPaymentId, e.getMessage());
                // Payment is still verified — details are best-effort
            }

            paymentRepo.save(payment);

            // Update order status
            OrderEntity order = orderRepo.findById(payment.getOrderId()).orElse(null);
            if (order != null) {
                order.setPaymentStatus("PAID");
                orderRepo.save(order);
            }

            Map<String, Object> resp = new HashMap<>();
            resp.put("status", "success");
            resp.put("message", "Payment verified successfully");
            resp.put("paymentId", payment.getId());
            resp.put("orderId", payment.getOrderId());
            resp.put("method", payment.getMethod());
            resp.put("utr", payment.getUtr());
            return ResponseEntity.ok(resp);
        } else {
            payment.setStatus("FAILED");

            // Try to fetch error details from Razorpay
            try {
                Map<String, Object> details = razorpayService.fetchPaymentDetails(razorpayPaymentId);
                payment.setErrorCode((String) details.get("error_code"));
                payment.setErrorDescription((String) details.get("error_description"));
                payment.setErrorReason((String) details.get("error_reason"));
            } catch (RazorpayException e) {
                log.warn("Could not fetch error details from Razorpay for {}: {}", razorpayPaymentId, e.getMessage());
            }

            paymentRepo.save(payment);

            OrderEntity order = orderRepo.findById(payment.getOrderId()).orElse(null);
            if (order != null) {
                order.setPaymentStatus("FAILED");
                orderRepo.save(order);
            }

            throw new BadRequestException("Payment verification failed. Signature mismatch.");
        }
    }

    // ---- Initiate refund for an order ----
    @PostMapping("/refund/{orderId}")
    public ResponseEntity<?> refundPayment(@PathVariable Long orderId,
                                            @RequestBody(required = false) Map<String, String> body) {
        Payment payment = paymentRepo.findByOrderId(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Payment", "orderId", orderId));

        if (!"PAID".equals(payment.getStatus())) {
            throw new BadRequestException("Cannot refund a payment with status: " + payment.getStatus());
        }
        if (payment.getRazorpayPaymentId() == null) {
            throw new BadRequestException("No Razorpay payment ID found for this order");
        }

        String reason = body != null ? body.get("reason") : null;
        String amountStr = body != null ? body.get("amount") : null;
        BigDecimal refundAmount = amountStr != null ? new BigDecimal(amountStr) : null;

        try {
            Map<String, Object> refundResult = razorpayService.initiateRefund(
                    payment.getRazorpayPaymentId(), refundAmount, reason);

            payment.setRefundId((String) refundResult.get("refund_id"));
            payment.setRefundStatus((String) refundResult.get("status"));
            payment.setRefundAmount(refundAmount != null ? refundAmount : payment.getAmount());
            payment.setRefundReason(reason);
            payment.setRefundedAt(LocalDateTime.now());
            payment.setStatus("REFUNDED");
            paymentRepo.save(payment);

            // Update order
            OrderEntity order = orderRepo.findById(orderId).orElse(null);
            if (order != null) {
                order.setPaymentStatus("REFUNDED");
                order.setRefunded(true);
                orderRepo.save(order);
            }

            Map<String, Object> resp = new HashMap<>(refundResult);
            resp.put("orderId", orderId);
            resp.put("paymentId", payment.getId());
            resp.put("message", "Refund initiated successfully");
            return ResponseEntity.ok(resp);

        } catch (RazorpayException e) {
            throw new PaymentException("Refund failed: " + e.getMessage(), e);
        }
    }

    // ---- Get payment status by order id ----
    @GetMapping("/order/{orderId}")
    public ResponseEntity<?> getByOrderId(@PathVariable Long orderId) {
        Payment payment = paymentRepo.findByOrderId(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Payment", "orderId", orderId));
        return ResponseEntity.ok(payment);
    }

    // ---- Admin: list all payments ----
    @GetMapping
    public List<Payment> all() { return paymentRepo.findAll(); }

    @GetMapping("/{id}")
    public ResponseEntity<Payment> get(@PathVariable Long id) {
        Payment payment = paymentRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payment", "id", id));
        return ResponseEntity.ok(payment);
    }

    // ─── Utility: resolve real client IP behind proxies ──────────────────

    private String resolveClientIp(HttpServletRequest request) {
        String xfHeader = request.getHeader("X-Forwarded-For");
        if (xfHeader != null && !xfHeader.isBlank()) {
            return xfHeader.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }
}
