package com.ketan.product.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private static final Logger log = LoggerFactory.getLogger(JwtAuthenticationFilter.class);

    private final JwtUtil jwtUtil;
    private final UserDetailsService userDetailsService;

    public JwtAuthenticationFilter(JwtUtil jwtUtil, UserDetailsService userDetailsService) {
        this.jwtUtil = jwtUtil;
        this.userDetailsService = userDetailsService;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        String header = request.getHeader(HttpHeaders.AUTHORIZATION);
        if (StringUtils.hasText(header) && header.startsWith("Bearer ")) {
            String token = header.substring(7);
            try {
                // 1. Parse & validate signature, expiration, issuer, audience
                var claims = jwtUtil.parseToken(token);
                String username = claims.getSubject();

                if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                    // 2. Load REAL authorities from DB (single source of truth)
                    UserDetails userDetails = userDetailsService.loadUserByUsername(username);

                    // 3. Cross-check: JWT roles must match DB roles
                    //    This prevents using old tokens after a role change/revocation
                    String jwtRoles = (String) claims.get("roles");
                    Set<String> dbRoles = userDetails.getAuthorities().stream()
                            .map(GrantedAuthority::getAuthority)
                            .collect(Collectors.toSet());
                    Set<String> tokenRoles = (jwtRoles != null && !jwtRoles.isBlank())
                            ? Arrays.stream(jwtRoles.split(",")).map(String::trim).collect(Collectors.toSet())
                            : Set.of();

                    if (!dbRoles.equals(tokenRoles)) {
                        // Roles changed since token was issued — reject this token
                        log.warn("[JWT] Role mismatch for user '{}': token={} db={} — rejecting token",
                                username, tokenRoles, dbRoles);
                        filterChain.doFilter(request, response);
                        return;
                    }

                    // 4. All checks passed — set authentication with DB authorities
                    var auth = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
                    SecurityContextHolder.getContext().setAuthentication(auth);
                }
            } catch (Exception ex) {
                // Invalid/tampered/expired token — reject silently (no auth set)
                log.debug("[JWT] Token rejected: {}", ex.getMessage());
            }
        }
        filterChain.doFilter(request, response);
    }
}
