package com.ketan.product.controller;

import com.ketan.product.exception.BadRequestException;
import com.ketan.product.exception.ForbiddenException;
import com.ketan.product.exception.ResourceNotFoundException;
import com.ketan.product.exception.UnauthorizedException;
import com.ketan.product.model.Address;
import com.ketan.product.model.User;
import com.ketan.product.repository.AddressRepository;
import com.ketan.product.repository.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;

@RestController
@RequestMapping("/api/addresses")
public class AddressController {
    private final AddressRepository addrRepo;
    private final UserRepository userRepo;

    private static final Set<String> INDIAN_STATES = Set.of(
        "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh",
        "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand",
        "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur",
        "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab",
        "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura",
        "Uttar Pradesh", "Uttarakhand", "West Bengal",
        "Andaman and Nicobar Islands", "Chandigarh", "Dadra and Nagar Haveli and Daman and Diu",
        "Delhi", "Jammu and Kashmir", "Ladakh", "Lakshadweep", "Puducherry"
    );

    public AddressController(AddressRepository addrRepo, UserRepository userRepo) { this.addrRepo = addrRepo; this.userRepo = userRepo; }

    @GetMapping
    public ResponseEntity<List<Address>> list(Authentication auth) {
        if (auth == null) throw new UnauthorizedException();
        return ResponseEntity.ok(addrRepo.findByUserUsername(auth.getName()));
    }

    @GetMapping("/states")
    public ResponseEntity<Set<String>> getStates() {
        return ResponseEntity.ok(INDIAN_STATES);
    }

    @PostMapping
    public ResponseEntity<Address> add(Authentication auth, @RequestBody Address address) {
        if (auth == null) throw new UnauthorizedException();

        // Validate required fields
        if (address.getLine1() == null || address.getLine1().isBlank())
            throw new BadRequestException("Address line 1 is required");
        if (address.getCity() == null || address.getCity().isBlank())
            throw new BadRequestException("City is required");
        if (address.getState() == null || address.getState().isBlank())
            throw new BadRequestException("State is required");
        if (address.getPostalCode() == null || address.getPostalCode().isBlank())
            throw new BadRequestException("Postal code is required");

        // Validate Indian state
        if (!INDIAN_STATES.contains(address.getState()))
            throw new BadRequestException("Invalid state. Please select a valid Indian state.");

        // Validate 6-digit Indian postal code
        if (!address.getPostalCode().matches("^[1-9][0-9]{5}$"))
            throw new BadRequestException("Postal code must be a valid 6-digit Indian PIN code");

        // Force country to India
        address.setCountry("India");

        User user = userRepo.findByUsername(auth.getName())
                .orElseThrow(() -> new ResourceNotFoundException("User", "username", auth.getName()));
        address.setUser(user);
        Address saved = addrRepo.save(address);
        return ResponseEntity.ok(saved);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(Authentication auth, @PathVariable Long id) {
        if (auth == null) throw new UnauthorizedException();
        Address a = addrRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Address", "id", id));
        if (!a.getUser().getUsername().equals(auth.getName()))
            throw new ForbiddenException("You can only delete your own addresses");
        addrRepo.delete(a);
        return ResponseEntity.noContent().build();
    }
}
