package com.ketan.product.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Arrays;

/**
 * General-purpose logging aspect using Spring AOP.
 *
 * <ul>
 *   <li><b>@Before</b>  – logs method entry with arguments</li>
 *   <li><b>@AfterReturning</b> – logs successful return value</li>
 *   <li><b>@AfterThrowing</b>  – logs exceptions thrown</li>
 *   <li><b>@After</b>   – logs method exit (always, like finally)</li>
 *   <li><b>@Around</b>  – logs execution time for service-layer methods</li>
 * </ul>
 */
@Aspect
@Component
public class LoggingAspect {

    private static final Logger log = LoggerFactory.getLogger(LoggingAspect.class);

    // ─── Pointcut Definitions ────────────────────────────────────────────

    /** All public methods inside any @RestController class */
    @Pointcut("within(@org.springframework.web.bind.annotation.RestController *)")
    public void controllerMethods() {}

    /** All public methods inside any @Service class */
    @Pointcut("within(@org.springframework.stereotype.Service *)")
    public void serviceMethods() {}

    /** All public methods inside any @Repository class */
    @Pointcut("within(@org.springframework.stereotype.Repository *)")
    public void repositoryMethods() {}

    /** All application-level beans (controllers + services + repositories) */
    @Pointcut("controllerMethods() || serviceMethods() || repositoryMethods()")
    public void applicationMethods() {}

    // ─── @Before – Log method entry ──────────────────────────────────────

    @Before("controllerMethods()")
    public void logBeforeController(JoinPoint jp) {
        String className  = jp.getTarget().getClass().getSimpleName();
        String methodName = jp.getSignature().getName();
        Object[] args     = jp.getArgs();

        log.info(">>> [BEFORE] {}.{}() called with args: {}",
                className, methodName, summarizeArgs(args));
    }

    @Before("serviceMethods()")
    public void logBeforeService(JoinPoint jp) {
        String className  = jp.getTarget().getClass().getSimpleName();
        String methodName = jp.getSignature().getName();
        Object[] args     = jp.getArgs();

        log.debug(">>> [BEFORE] {}.{}() called with args: {}",
                className, methodName, summarizeArgs(args));
    }

    // ─── @AfterReturning – Log successful result ─────────────────────────

    @AfterReturning(pointcut = "controllerMethods()", returning = "result")
    public void logAfterReturningController(JoinPoint jp, Object result) {
        String className  = jp.getTarget().getClass().getSimpleName();
        String methodName = jp.getSignature().getName();

        log.info("<<< [AFTER-RETURN] {}.{}() returned: {}",
                className, methodName, summarizeResult(result));
    }

    @AfterReturning(pointcut = "serviceMethods()", returning = "result")
    public void logAfterReturningService(JoinPoint jp, Object result) {
        String className  = jp.getTarget().getClass().getSimpleName();
        String methodName = jp.getSignature().getName();

        log.debug("<<< [AFTER-RETURN] {}.{}() returned: {}",
                className, methodName, summarizeResult(result));
    }

    // ─── @AfterThrowing – Log exceptions ─────────────────────────────────

    @AfterThrowing(pointcut = "applicationMethods()", throwing = "ex")
    public void logAfterThrowing(JoinPoint jp, Throwable ex) {
        String className  = jp.getTarget().getClass().getSimpleName();
        String methodName = jp.getSignature().getName();

        log.error("!!! [EXCEPTION] {}.{}() threw {}: {}",
                className, methodName, ex.getClass().getSimpleName(), ex.getMessage());
    }

    // ─── @After – Log method exit (finally) ──────────────────────────────

    @After("controllerMethods()")
    public void logAfterController(JoinPoint jp) {
        String className  = jp.getTarget().getClass().getSimpleName();
        String methodName = jp.getSignature().getName();

        log.info("--- [AFTER] {}.{}() completed (finally)", className, methodName);
    }

    // ─── @Around – Log execution time for services ───────────────────────

    @Around("serviceMethods()")
    public Object logAroundService(ProceedingJoinPoint pjp) throws Throwable {
        String className  = pjp.getTarget().getClass().getSimpleName();
        String methodName = pjp.getSignature().getName();

        log.debug("==> [AROUND-START] {}.{}()", className, methodName);
        long start = System.currentTimeMillis();

        try {
            Object result = pjp.proceed();
            long duration = System.currentTimeMillis() - start;

            log.info("==> [AROUND-END] {}.{}() executed in {} ms",
                    className, methodName, duration);
            return result;
        } catch (Throwable t) {
            long duration = System.currentTimeMillis() - start;

            log.error("==> [AROUND-FAIL] {}.{}() failed after {} ms — {}: {}",
                    className, methodName, duration,
                    t.getClass().getSimpleName(), t.getMessage());
            throw t;
        }
    }

    @Around("repositoryMethods()")
    public Object logAroundRepository(ProceedingJoinPoint pjp) throws Throwable {
        String className  = pjp.getTarget().getClass().getSimpleName();
        String methodName = pjp.getSignature().getName();

        long start = System.currentTimeMillis();

        try {
            Object result = pjp.proceed();
            long duration = System.currentTimeMillis() - start;

            if (duration > 100) {
                log.warn("==> [SLOW-QUERY] {}.{}() took {} ms",
                        className, methodName, duration);
            } else {
                log.debug("==> [REPO] {}.{}() executed in {} ms",
                        className, methodName, duration);
            }
            return result;
        } catch (Throwable t) {
            long duration = System.currentTimeMillis() - start;

            log.error("==> [REPO-FAIL] {}.{}() failed after {} ms — {}: {}",
                    className, methodName, duration,
                    t.getClass().getSimpleName(), t.getMessage());
            throw t;
        }
    }

    // ─── Helper methods ──────────────────────────────────────────────────

    /**
     * Produces a short summary of method arguments, avoiding logging
     * sensitive objects like HttpServletRequest/Response in full.
     */
    private String summarizeArgs(Object[] args) {
        if (args == null || args.length == 0) return "[]";

        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < args.length; i++) {
            if (i > 0) sb.append(", ");
            sb.append(summarizeSingle(args[i]));
        }
        sb.append("]");
        return sb.toString();
    }

    private String summarizeSingle(Object arg) {
        if (arg == null) return "null";

        String typeName = arg.getClass().getSimpleName();

        // Skip verbose framework types
        if (typeName.contains("Request") || typeName.contains("Response")
                || typeName.contains("Session") || typeName.contains("Pageable")) {
            return typeName + "{...}";
        }

        String str = arg.toString();
        // Truncate very long strings (e.g. base64 images, large request bodies)
        if (str.length() > 200) {
            return typeName + "{" + str.substring(0, 200) + "…}";
        }
        return str;
    }

    private String summarizeResult(Object result) {
        if (result == null) return "null";

        String typeName = result.getClass().getSimpleName();

        // For ResponseEntity, show status + body type
        if (typeName.equals("ResponseEntity")) {
            return result.toString().length() > 300
                    ? typeName + "{...truncated...}"
                    : result.toString();
        }

        // For collections, show size
        if (result instanceof java.util.Collection<?> c) {
            return typeName + "[size=" + c.size() + "]";
        }

        String str = result.toString();
        if (str.length() > 300) {
            return typeName + "{" + str.substring(0, 300) + "…}";
        }
        return str;
    }
}
