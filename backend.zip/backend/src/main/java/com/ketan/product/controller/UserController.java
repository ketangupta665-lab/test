package com.ketan.product.controller;

import com.ketan.product.exception.BadRequestException;
import com.ketan.product.exception.ConflictException;
import com.ketan.product.exception.ResourceNotFoundException;
import com.ketan.product.exception.UnauthorizedException;
import com.ketan.product.model.Address;
import com.ketan.product.model.User;
import com.ketan.product.repository.UserRepository;
import com.ketan.product.service.EmailService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
public class UserController {
    private final UserRepository repo;
    private final PasswordEncoder encoder;
    private final EmailService emailService;

    public UserController(UserRepository repo, PasswordEncoder encoder, EmailService emailService) {
        this.repo = repo;
        this.encoder = encoder;
        this.emailService = emailService;
    }

    @GetMapping
    public List<User> all() { return repo.findAll(); }

    @GetMapping("/{id}")
    public ResponseEntity<User> get(@PathVariable Long id) {
        User user = repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User", "id", id));
        return ResponseEntity.ok(user);
    }

    // Registration endpoint. Address is optional in the payload.
    @PostMapping("/register")
    public ResponseEntity<User> register(@RequestBody @Valid User user) {
        if (user.getUsername() == null || user.getPassword() == null)
            throw new BadRequestException("Username and password are required");
        if (repo.findByUsername(user.getUsername()).isPresent())
            throw new ConflictException("Username '" + user.getUsername() + "' is already taken");
        user.setPassword(encoder.encode(user.getPassword()));
        // ensure role
        user.setRoles("ROLE_USER");
        // if addresses provided, assign back-reference
        if (user.getAddresses() != null) {
            for (Address a : user.getAddresses()) a.setUser(user);
        }
        User saved = repo.save(user);

        // Send welcome email (non-blocking – failures are logged, not thrown)
        if (saved.getEmail() != null && !saved.getEmail().isBlank()) {
            String name = saved.getName() != null ? saved.getName() : saved.getUsername();
            String subject = "Welcome to Our Store, " + name + "!";
            String body = "Hi " + name + ",\n\n"
                    + "Thank you for registering with us! Your account has been created successfully.\n\n"
                    + "Username: " + saved.getUsername() + "\n"
                    + "Email: " + saved.getEmail() + "\n\n"
                    + "You can now browse our catalog, add items to your cart, and place orders.\n\n"
                    + "If you have any questions, feel free to reach out to our support team.\n\n"
                    + "Happy shopping!\n"
                    + "— The Store Team";
            emailService.sendSimpleEmail(saved.getEmail(), subject, body);
        }

        return ResponseEntity.ok(saved);
    }

    // simple endpoint to get current authenticated user
    @GetMapping("/me")
    public ResponseEntity<User> me(Authentication auth) {
        if (auth == null) throw new UnauthorizedException();
        User user = repo.findByUsername(auth.getName())
                .orElseThrow(() -> new ResourceNotFoundException("User", "username", auth.getName()));
        return ResponseEntity.ok(user);
    }
}
