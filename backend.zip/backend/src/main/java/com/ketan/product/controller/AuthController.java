package com.ketan.product.controller;

import com.ketan.product.exception.UnauthorizedException;
import com.ketan.product.security.JwtUtil;
import com.ketan.product.service.RefreshTokenService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import com.ketan.product.model.User;
import com.ketan.product.repository.UserRepository;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.Duration;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AuthenticationManager authManager;
    private final JwtUtil jwtUtil;
    private final RefreshTokenService refreshService;
    private final UserRepository userRepo;

    @org.springframework.beans.factory.annotation.Value("${jwt.access-token-expiry:900000}")
    private long accessTokenExpiry; // milliseconds (default 15 min)

    @org.springframework.beans.factory.annotation.Value("${jwt.refresh-token-expiry:604800}")
    private long refreshValidity; // seconds (default 7 days)

    @org.springframework.beans.factory.annotation.Value("${jwt.refresh-threshold:120000}")
    private long refreshThreshold; // milliseconds (default 2 min)

    public AuthController(AuthenticationManager authManager, JwtUtil jwtUtil, RefreshTokenService refreshService, UserRepository userRepo) {
        this.authManager = authManager;
        this.jwtUtil = jwtUtil;
        this.refreshService = refreshService;
        this.userRepo = userRepo;
    }

    public static class LoginRequest { public String username; public String password; }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest req) {
        Authentication auth = authManager.authenticate(new UsernamePasswordAuthenticationToken(req.username, req.password));
        // look up user roles from DB
        String roles = userRepo.findByUsername(req.username).map(User::getRoles).orElse("ROLE_USER");
        // create access token with roles
        String accessToken = jwtUtil.generateToken(req.username, roles, accessTokenExpiry);

        // create refresh token (DB-backed) valid for refreshValidity
        var refresh = refreshService.createTokenForUser(req.username, refreshValidity);
        ResponseCookie cookie = ResponseCookie.from("refreshToken", refresh.getToken())
                .httpOnly(true)
                .path("/api/auth")
                .maxAge(Duration.ofSeconds(refreshValidity))
                .sameSite("Lax")
                .build();

        return ResponseEntity.ok().header(HttpHeaders.SET_COOKIE, cookie.toString()).body(Map.of("token", accessToken));
    }

    @PostMapping("/refresh")
    public ResponseEntity<?> refresh(@CookieValue(value = "refreshToken", required = false) String refreshToken) {
        if (refreshToken == null || refreshToken.isBlank()) throw new UnauthorizedException("Missing refresh token");
        var opt = refreshService.findByToken(refreshToken);
        if (opt.isEmpty()) throw new UnauthorizedException("Invalid refresh token");
        var tokenEntity = opt.get();
        if (tokenEntity.getExpiryDate().isBefore(java.time.Instant.now())) {
            refreshService.removeToken(tokenEntity);
            throw new UnauthorizedException("Refresh token has expired. Please log in again.");
        }

        String username = tokenEntity.getUsername();
        String roles = userRepo.findByUsername(username).map(User::getRoles).orElse("ROLE_USER");
        String accessToken = jwtUtil.generateToken(username, roles, accessTokenExpiry);

        // rotate refresh token: issue a new one and delete old
        refreshService.removeToken(tokenEntity);
        var newRefresh = refreshService.createTokenForUser(username, refreshValidity);
        ResponseCookie cookie = ResponseCookie.from("refreshToken", newRefresh.getToken())
                .httpOnly(true)
                .path("/api/auth")
                .maxAge(Duration.ofSeconds(refreshValidity))
                .sameSite("Lax")
                .build();

        return ResponseEntity.ok().header(HttpHeaders.SET_COOKIE, cookie.toString()).body(Map.of("token", accessToken));
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(@CookieValue(value = "refreshToken", required = false) String refreshToken) {
        if (refreshToken != null && !refreshToken.isBlank()){
            var opt = refreshService.findByToken(refreshToken);
            opt.ifPresent(refreshService::removeToken);
        }
        // clear cookie
        ResponseCookie cookie = ResponseCookie.from("refreshToken", "deleted")
                .httpOnly(true)
                .path("/api/auth")
                .maxAge(Duration.ofSeconds(0))
                .sameSite("Lax")
                .build();
        return ResponseEntity.ok().header(HttpHeaders.SET_COOKIE, cookie.toString()).body(Map.of("status","logged_out"));
    }

    /** Public endpoint: returns JWT timing config so the frontend can schedule refreshes. */
    @GetMapping("/token-config")
    public Map<String, Object> tokenConfig() {
        return Map.of(
            "accessTokenExpiryMs", accessTokenExpiry,
            "refreshThresholdMs", refreshThreshold,
            "refreshTokenExpirySec", refreshValidity
        );
    }
}
