package com.ketan.product.config;

import com.ketan.product.security.JwtAuthenticationFilter;
import com.ketan.product.security.JwtUtil;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;

@Configuration
@EnableMethodSecurity
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authConfig) throws Exception {
        return authConfig.getAuthenticationManager();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http, JwtUtil jwtUtil, UserDetailsService userDetailsService) throws Exception {
        JwtAuthenticationFilter jwtFilter = new JwtAuthenticationFilter(jwtUtil, userDetailsService);

        http.csrf(csrf -> csrf.disable())
            .sessionManagement(sess -> sess.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers(HttpMethod.POST, "/api/users/register").permitAll()
                .requestMatchers("/api/auth/**").permitAll()
                // Admin-only catalog endpoints (must come BEFORE the general catalog permitAll)
                .requestMatchers(HttpMethod.POST, "/api/catalog/*/stock").hasRole("ADMIN")
                .requestMatchers(HttpMethod.POST, "/api/catalog/*/stock/adjust").hasRole("ADMIN")
                .requestMatchers(HttpMethod.POST, "/api/catalog/*/approve").hasRole("ADMIN")
                .requestMatchers(HttpMethod.GET, "/api/catalog/pending").hasRole("ADMIN")
                // PRODUCT_ADMIN: can create products (which still need ADMIN approval)
                .requestMatchers(HttpMethod.POST, "/api/catalog").hasAnyRole("ADMIN", "PRODUCT_ADMIN")
                // Public catalog endpoints
                .requestMatchers(HttpMethod.GET, "/api/catalog/**").permitAll()
                // Public banner endpoint
                .requestMatchers(HttpMethod.GET, "/api/banners/active").permitAll()
                // Banner admin endpoints
                .requestMatchers("/api/banners/**").hasRole("ADMIN")
                .requestMatchers("/api/payments/razorpay-key").permitAll()
                .requestMatchers(HttpMethod.POST, "/api/payments/verify").permitAll()
                .requestMatchers(HttpMethod.POST, "/api/payments/refund/**").hasRole("ADMIN")
                // PRODUCT_ADMIN can view inventory and pending products
                .requestMatchers(HttpMethod.GET, "/api/admin/inventory").hasAnyRole("ADMIN", "PRODUCT_ADMIN")
                .requestMatchers(HttpMethod.POST, "/api/admin/products").hasAnyRole("ADMIN", "PRODUCT_ADMIN")
                .requestMatchers("/api/admin/**").hasRole("ADMIN")
                .requestMatchers("/api/audit/my-activity", "/api/audit/my-interest").authenticated()
                .requestMatchers("/api/audit/**").hasRole("ADMIN")
                .requestMatchers("/api/**").authenticated()
                .anyRequest().permitAll()
            );

        // Return 401 (not 403) for unauthenticated requests
        http.exceptionHandling(ex -> ex
            .authenticationEntryPoint((req, res, authEx) -> res.sendError(401, "Unauthorized"))
        );

        http.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

        // allow H2 console frames
        http.headers(headers -> headers.frameOptions(frame -> frame.disable()));
        return http.build();
    }
}
