package com.ketan.product.repository;

import com.ketan.product.model.Banner;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BannerRepository extends JpaRepository<Banner, Long> {
    List<Banner> findByApprovedTrueAndActiveTrueOrderByDisplayOrderAsc();
    List<Banner> findByApprovedFalse();
    List<Banner> findAllByOrderByDisplayOrderAsc();
}
