package com.ketan.product.service;

import com.ketan.product.exception.BadRequestException;
import com.ketan.product.model.*;
import com.ketan.product.repository.CouponRepository;
import com.ketan.product.repository.InvoiceRepository;
import com.ketan.product.repository.OrderRepository;
import com.ketan.product.repository.PaymentRepository;
import com.ketan.product.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;

@Service
public class OrderService {

    private static final Logger log = LoggerFactory.getLogger(OrderService.class);

    private final OrderRepository orderRepo;
    private final InvoiceRepository invoiceRepo;
    private final PaymentRepository paymentRepo;
    private final CouponRepository couponRepo;
    private final UserRepository userRepo;
    private final EmailService emailService;
    private final SmsService smsService;

    public OrderService(OrderRepository orderRepo, InvoiceRepository invoiceRepo,
                        PaymentRepository paymentRepo, CouponRepository couponRepo,
                        UserRepository userRepo, EmailService emailService,
                        SmsService smsService) {
        this.orderRepo = orderRepo;
        this.invoiceRepo = invoiceRepo;
        this.paymentRepo = paymentRepo;
        this.couponRepo = couponRepo;
        this.userRepo = userRepo;
        this.emailService = emailService;
        this.smsService = smsService;
    }

    public OrderEntity createFromCart(Cart cart) {
        return createFromCart(cart, null);
    }

    public OrderEntity createFromCart(Cart cart, String couponCode) {
        OrderEntity order = new OrderEntity();
        StringBuilder productNames = new StringBuilder();
        int totalQty = 0;
        BigDecimal subtotal = BigDecimal.ZERO;
        for (CartItem it : cart.getItems()) {
            productNames.append(it.getProductId()).append(";");
            totalQty += it.getQuantity();
            if (it.getPrice() != null)
                subtotal = subtotal.add(it.getPrice().multiply(BigDecimal.valueOf(it.getQuantity())));
        }

        // Apply coupon if provided
        BigDecimal couponDiscount = BigDecimal.ZERO;
        boolean couponFreeDelivery = false;
        Coupon appliedCoupon = null;

        if (couponCode != null && !couponCode.isBlank()) {
            appliedCoupon = couponRepo.findByCodeIgnoreCase(couponCode.trim())
                    .orElseThrow(() -> new BadRequestException("Invalid coupon code"));

            if (!appliedCoupon.isActive())
                throw new BadRequestException("This coupon is no longer active");
            if (appliedCoupon.getExpiryDate() != null && LocalDateTime.now().isAfter(appliedCoupon.getExpiryDate()))
                throw new BadRequestException("This coupon has expired");
            if (appliedCoupon.getUsageLimit() > 0 && appliedCoupon.getUsedCount() >= appliedCoupon.getUsageLimit())
                throw new BadRequestException("This coupon has reached its usage limit");
            if (orderRepo.existsByUserUsernameAndCouponCode(cart.getOwner(), appliedCoupon.getCode()))
                throw new BadRequestException("You have already used this coupon");
            if (appliedCoupon.getMinOrderAmount() != null && subtotal.compareTo(appliedCoupon.getMinOrderAmount()) < 0)
                throw new BadRequestException("Minimum order amount of ₹" + appliedCoupon.getMinOrderAmount().intValue() + " required");

            switch (appliedCoupon.getDiscountType()) {
                case "PERCENTAGE":
                    couponDiscount = subtotal.multiply(appliedCoupon.getDiscountValue())
                            .divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
                    if (appliedCoupon.getMaxDiscountAmount() != null &&
                            couponDiscount.compareTo(appliedCoupon.getMaxDiscountAmount()) > 0)
                        couponDiscount = appliedCoupon.getMaxDiscountAmount();
                    break;
                case "FLAT_AMOUNT":
                    couponDiscount = appliedCoupon.getDiscountValue();
                    if (couponDiscount.compareTo(subtotal) > 0) couponDiscount = subtotal;
                    break;
                case "FREE_DELIVERY":
                    couponFreeDelivery = true;
                    break;
            }
        }

        BigDecimal discountedSubtotal = subtotal.subtract(couponDiscount);

        // Apply shipping charge: ₹49 if subtotal < ₹299, else free; coupon can override
        BigDecimal shippingCharge;
        if (couponFreeDelivery) {
            shippingCharge = BigDecimal.ZERO;
        } else {
            shippingCharge = subtotal.compareTo(BigDecimal.valueOf(299)) < 0
                    ? BigDecimal.valueOf(49) : BigDecimal.ZERO;
        }

        BigDecimal finalTotal = discountedSubtotal.add(shippingCharge);

        // Look up user by cart owner (username)
        User user = userRepo.findByUsername(cart.getOwner()).orElse(null);
        if (user == null) {
            user = userRepo.findByEmail(cart.getOwner()).orElse(null);
        }

        order.setProduct(productNames.toString());
        order.setQuantity(totalQty);
        order.setShippingCharge(shippingCharge);
        order.setCouponCode(appliedCoupon != null ? appliedCoupon.getCode() : null);
        order.setCouponDiscount(couponDiscount);
        order.setAmount(finalTotal);
        order.setUser(user);
        order.setPaymentStatus("PENDING");
        order.setShipmentStatus("PENDING");
        OrderEntity saved = orderRepo.save(order);

        // Increment coupon usage
        if (appliedCoupon != null) {
            appliedCoupon.setUsedCount(appliedCoupon.getUsedCount() + 1);
            couponRepo.save(appliedCoupon);
        }

        Invoice inv = new Invoice();
        inv.setOrderId(saved.getId());
        inv.setTotal(finalTotal);
        invoiceRepo.save(inv);

        Payment pay = new Payment();
        pay.setOrderId(saved.getId());
        pay.setAmount(finalTotal);
        pay.setStatus("PENDING");
        paymentRepo.save(pay);

        // Send order confirmation email (async — does not block checkout)
        if (user != null && user.getEmail() != null) {
            emailService.sendOrderConfirmation(user.getEmail(), user.getName(), saved);
            log.info("Order confirmation email queued for order #{} to {}", saved.getId(), user.getEmail());
        }

        // Send order confirmation SMS
        if (user != null && user.getPhone() != null && !user.getPhone().isBlank()) {
            String sms = "Shyamaju Store: Order #" + saved.getId()
                    + " placed successfully. Amount Rs." + finalTotal.intValue()
                    + ". Thank you for shopping with us!";
            smsService.sendSms(user.getPhone(), sms);
        }

        return saved;
    }
}
