package com.ketan.product.controller;

import com.ketan.product.model.Product;
import com.ketan.product.service.CatalogService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.math.BigDecimal;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

@RestController
@RequestMapping("/api/catalog")
public class CatalogController {
    private final CatalogService service;

    public CatalogController(CatalogService service) { this.service = service; }

    // Public listing - only approved products
    @GetMapping
    public List<Product> list() { return service.list(); }

    @GetMapping("/search")
    public Page<Product> search(@RequestParam(required = false) String q,
                                @RequestParam(required = false) BigDecimal minPrice,
                                @RequestParam(required = false) BigDecimal maxPrice,
                                @RequestParam(required = false, defaultValue = "false") boolean fuzzy,
                                Pageable pageable) {
        return service.search(q, minPrice, maxPrice, pageable, fuzzy);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/{id}/stock")
    public Product setStock(@PathVariable Long id, @RequestParam int qty) { return service.setStock(id, qty); }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/{id}/stock/adjust")
    public Product adjustStock(@PathVariable Long id, @RequestParam int delta) { return service.adjustStock(id, delta); }

    @GetMapping("/{id}/availability")
    public java.util.Map<String,Object> availability(@PathVariable Long id) {
        Product p = service.get(id);
        if (p == null) return java.util.Map.of("available", false);
        return java.util.Map.of("available", p.isInStock(), "stock", p.getStock());
    }

    @GetMapping("/{id}")
    public Product get(@PathVariable Long id) { return service.get(id); }

    // Create new product (will be saved as not approved)
    @PostMapping
    public Product create(@RequestBody Product p) { return service.save(p); }

    // Admin endpoints
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/pending")
    public List<Product> pending() { return service.pending(); }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/{id}/approve")
    public Product approve(@PathVariable Long id) { return service.approve(id); }
}
