package com.ketan.product.controller;

import com.ketan.product.exception.BadRequestException;
import com.ketan.product.model.Cart;
import com.ketan.product.service.CartService;
import com.ketan.product.service.OrderService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/cart")
public class CartController {
    private final CartService cartService;
    private final OrderService orderService;

    public CartController(CartService cartService, OrderService orderService) {
        this.cartService = cartService;
        this.orderService = orderService;
    }

    @GetMapping
    public Cart getCart(@AuthenticationPrincipal UserDetails user) {
        return cartService.getOrCreateCart(user.getUsername());
    }

    @PostMapping("/add")
    public Cart addItem(@AuthenticationPrincipal UserDetails user, @RequestParam Long productId, @RequestParam(defaultValue = "1") int qty) {
        return cartService.addItem(user.getUsername(), productId, qty);
    }

    @PostMapping("/update")
    public Cart updateItemQty(@AuthenticationPrincipal UserDetails user, @RequestParam Long itemId, @RequestParam int qty) {
        return cartService.updateItemQty(user.getUsername(), itemId, qty);
    }

    @PostMapping("/remove")
    public Cart removeItem(@AuthenticationPrincipal UserDetails user, @RequestParam Long itemId) {
        return cartService.removeItem(user.getUsername(), itemId);
    }

    @PostMapping("/checkout")
    public Map<String, Object> checkout(@AuthenticationPrincipal UserDetails user,
                                        @RequestParam(required = false) String couponCode) {
        Cart cart = cartService.getOrCreateCart(user.getUsername());
        if (cart.getItems().isEmpty()) throw new BadRequestException("Cart is empty. Add items before checkout.");
        var order = orderService.createFromCart(cart, couponCode);
        cartService.clearCart(user.getUsername());
        return Map.of("status", "ORDER_CREATED", "orderId", order.getId());
    }
}
