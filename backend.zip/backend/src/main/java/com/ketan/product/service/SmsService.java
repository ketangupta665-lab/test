package com.ketan.product.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Generic SMS service that works with any HTTP-based SMS gateway.
 * Configure your provider in application.properties:
 *   sms.api-url       — the gateway HTTP endpoint
 *   sms.api-key       — your API key / auth token
 *   sms.sender-id     — sender ID (e.g. SHYMJU)
 *   sms.route         — route type (e.g. "v3" for Fast2SMS, "transactional" etc.)
 *
 * Supported providers out-of-the-box: Fast2SMS, MSG91, or any REST gateway.
 */
@Service
public class SmsService {

    private static final Logger log = LoggerFactory.getLogger(SmsService.class);

    @Value("${sms.api-url:}")
    private String apiUrl;

    @Value("${sms.api-key:}")
    private String apiKey;

    @Value("${sms.sender-id:SHYMJU}")
    private String senderId;

    @Value("${sms.route:v3}")
    private String route;

    private final RestTemplate restTemplate = new RestTemplate();

    public boolean isConfigured() {
        return apiUrl != null && !apiUrl.isBlank()
                && apiKey != null && !apiKey.isBlank();
    }

    /**
     * Send an OTP via Fast2SMS Quick SMS route (no DLT or website verification required).
     * Uses a plain text message rather than Fast2SMS's OTP template, so it works on any
     * unverified account.
     */
    public boolean sendOtp(String phone, String code) {
        String message = "Your Shyamaju Store OTP is " + code + ". Valid for 5 minutes. Do not share it with anyone.";
        return sendQuickSms(phone, message, "OTP");
    }

    private boolean sendQuickSms(String phone, String message, String logTag) {
        if (!isConfigured()) {
            log.info("[SMS {}] Not configured — message to {} skipped", logTag, phone);
            return false;
        }
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("authorization", apiKey);

            Map<String, Object> body = Map.of(
                    "route", "q",
                    "message", message,
                    "language", "english",
                    "flash", 0,
                    "numbers", phone
            );

            HttpEntity<Map<String, Object>> entity = new HttpEntity<>(body, headers);
            ResponseEntity<String> response = restTemplate.postForEntity(apiUrl, entity, String.class);

            if (response.getStatusCode().is2xxSuccessful()) {
                log.info("[SMS {}] Sent to {}", logTag, phone);
                return true;
            }
            log.warn("[SMS {}] Failed to send to {} — status={}, body={}", logTag, phone, response.getStatusCode(), response.getBody());
            return false;
        } catch (Exception e) {
            log.error("[SMS {}] Error sending to {}: {}", logTag, phone, e.getMessage());
            return false;
        }
    }

    /**
     * Send SMS to a single phone number.
     */
    public boolean sendSms(String phone, String message) {
        if (!isConfigured()) {
            log.info("[SMS] Not configured — message to {} skipped: {}", phone, message);
            return false;
        }
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("authorization", apiKey);

            Map<String, Object> body = Map.of(
                    "route", route,
                    "sender_id", senderId,
                    "message", message,
                    "language", "english",
                    "numbers", phone
            );

            HttpEntity<Map<String, Object>> entity = new HttpEntity<>(body, headers);
            ResponseEntity<String> response = restTemplate.postForEntity(apiUrl, entity, String.class);

            if (response.getStatusCode().is2xxSuccessful()) {
                log.info("[SMS] Sent to {}: {}", phone, message.substring(0, Math.min(50, message.length())));
                return true;
            } else {
                log.warn("[SMS] Failed to send to {} — status={}, body={}", phone, response.getStatusCode(), response.getBody());
                return false;
            }
        } catch (Exception e) {
            log.error("[SMS] Error sending to {}: {}", phone, e.getMessage());
            return false;
        }
    }

    /**
     * Send the same SMS to multiple phone numbers (bulk/campaign).
     * Returns the count of successfully sent messages.
     */
    @Async
    public void sendBulkSms(List<String> phones, String message, BulkSmsCallback callback) {
        if (!isConfigured()) {
            log.info("[SMS] Not configured — bulk message to {} numbers skipped", phones.size());
            if (callback != null) callback.onComplete(0, phones.size());
            return;
        }

        // Try comma-separated bulk (Fast2SMS style) first
        try {
            String numbers = String.join(",", phones);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("authorization", apiKey);

            Map<String, Object> body = Map.of(
                    "route", route,
                    "sender_id", senderId,
                    "message", message,
                    "language", "english",
                    "numbers", numbers
            );

            HttpEntity<Map<String, Object>> entity = new HttpEntity<>(body, headers);
            ResponseEntity<String> response = restTemplate.postForEntity(apiUrl, entity, String.class);

            if (response.getStatusCode().is2xxSuccessful()) {
                log.info("[SMS] Bulk sent to {} numbers", phones.size());
                if (callback != null) callback.onComplete(phones.size(), phones.size());
                return;
            }
        } catch (Exception e) {
            log.warn("[SMS] Bulk send failed, falling back to individual: {}", e.getMessage());
        }

        // Fallback: send individually
        AtomicInteger success = new AtomicInteger(0);
        for (String phone : phones) {
            if (sendSms(phone, message)) success.incrementAndGet();
        }
        log.info("[SMS] Campaign complete: {}/{} sent", success.get(), phones.size());
        if (callback != null) callback.onComplete(success.get(), phones.size());
    }

    /**
     * Callback interface for bulk SMS completion reporting.
     */
    public interface BulkSmsCallback {
        void onComplete(int sent, int total);
    }
}
