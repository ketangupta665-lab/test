package com.ketan.product.controller;

import com.ketan.product.exception.ResourceNotFoundException;
import com.ketan.product.model.Banner;
import com.ketan.product.repository.BannerRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/banners")
public class BannerController {

    private final BannerRepository bannerRepo;

    public BannerController(BannerRepository bannerRepo) {
        this.bannerRepo = bannerRepo;
    }

    /** Public: get all approved + active banners for homepage */
    @GetMapping("/active")
    public List<Banner> activeBanners() {
        return bannerRepo.findByApprovedTrueAndActiveTrueOrderByDisplayOrderAsc();
    }

    /** Admin: get all banners */
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping
    public List<Banner> allBanners() {
        return bannerRepo.findAllByOrderByDisplayOrderAsc();
    }

    /** Admin: get pending (unapproved) banners */
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/pending")
    public List<Banner> pendingBanners() {
        return bannerRepo.findByApprovedFalse();
    }

    /** Admin: create a new banner (saved as unapproved, needs final approval) */
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public Banner createBanner(@RequestBody Banner banner, Authentication auth) {
        banner.setApproved(false);
        banner.setCreatedBy(auth.getName());
        return bannerRepo.save(banner);
    }

    /** Admin: approve a banner (final go-live) */
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/{id}/approve")
    public ResponseEntity<Banner> approveBanner(@PathVariable Long id) {
        return bannerRepo.findById(id).map(b -> {
            b.setApproved(true);
            bannerRepo.save(b);
            return ResponseEntity.ok(b);
        }).orElseThrow(() -> new ResourceNotFoundException("Banner", "id", id));
    }

    /** Admin: reject / unapprove a banner */
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/{id}/reject")
    public ResponseEntity<Banner> rejectBanner(@PathVariable Long id) {
        return bannerRepo.findById(id).map(b -> {
            b.setApproved(false);
            bannerRepo.save(b);
            return ResponseEntity.ok(b);
        }).orElseThrow(() -> new ResourceNotFoundException("Banner", "id", id));
    }

    /** Admin: toggle active/inactive */
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/{id}/toggle")
    public ResponseEntity<Banner> toggleBanner(@PathVariable Long id) {
        return bannerRepo.findById(id).map(b -> {
            b.setActive(!b.isActive());
            bannerRepo.save(b);
            return ResponseEntity.ok(b);
        }).orElseThrow(() -> new ResourceNotFoundException("Banner", "id", id));
    }

    /** Admin: update banner */
    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/{id}")
    public ResponseEntity<Banner> updateBanner(@PathVariable Long id, @RequestBody Banner updated) {
        return bannerRepo.findById(id).map(b -> {
            if (updated.getTitle() != null) b.setTitle(updated.getTitle());
            if (updated.getSubtitle() != null) b.setSubtitle(updated.getSubtitle());
            if (updated.getLinkUrl() != null) b.setLinkUrl(updated.getLinkUrl());
            if (updated.getLinkText() != null) b.setLinkText(updated.getLinkText());
            if (updated.getImages() != null && !updated.getImages().isEmpty()) b.setImages(updated.getImages());
            b.setDisplayOrder(updated.getDisplayOrder());
            b.setApproved(false); // re-approval needed after edit
            bannerRepo.save(b);
            return ResponseEntity.ok(b);
        }).orElseThrow(() -> new ResourceNotFoundException("Banner", "id", id));
    }

    /** Admin: delete banner */
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBanner(@PathVariable Long id) {
        if (!bannerRepo.existsById(id)) throw new ResourceNotFoundException("Banner", "id", id);
        bannerRepo.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
