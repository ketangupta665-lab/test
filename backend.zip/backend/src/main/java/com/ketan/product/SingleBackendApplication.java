package com.ketan.product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class SingleBackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(SingleBackendApplication.class, args);
    }
}
