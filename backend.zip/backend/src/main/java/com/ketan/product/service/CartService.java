package com.ketan.product.service;

import com.ketan.product.exception.ResourceNotFoundException;
import com.ketan.product.model.Cart;
import com.ketan.product.model.CartItem;
import com.ketan.product.model.Product;
import com.ketan.product.repository.CartRepository;
import com.ketan.product.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class CartService {
    private final CartRepository cartRepo;
    private final ProductRepository productRepo;

    public CartService(CartRepository cartRepo, ProductRepository productRepo) {
        this.cartRepo = cartRepo;
        this.productRepo = productRepo;
    }

    public Cart getOrCreateCart(String owner) {
        return cartRepo.findByOwner(owner).orElseGet(() -> {
            Cart c = new Cart();
            c.setOwner(owner);
            return cartRepo.save(c);
        });
    }

    public Cart addItem(String owner, Long productId, int qty) {
        Cart cart = getOrCreateCart(owner);
        Product p = productRepo.findById(productId)
                .orElseThrow(() -> new ResourceNotFoundException("Product", "id", productId));
        // Check if item already exists — merge quantities
        for (CartItem existing : cart.getItems()) {
            if (existing.getProductId().equals(productId)) {
                existing.setQuantity(existing.getQuantity() + qty);
                existing.setPrice(p.getPrice());
                return cartRepo.save(cart);
            }
        }
        CartItem item = new CartItem();
        item.setProductId(p.getId());
        item.setQuantity(qty);
        item.setPrice(p.getPrice());
        cart.getItems().add(item);
        return cartRepo.save(cart);
    }

    public Cart updateItemQty(String owner, Long itemId, int qty) {
        Cart cart = getOrCreateCart(owner);
        for (CartItem item : cart.getItems()) {
            if (item.getId().equals(itemId)) {
                if (qty <= 0) {
                    cart.getItems().remove(item);
                } else {
                    item.setQuantity(qty);
                }
                break;
            }
        }
        return cartRepo.save(cart);
    }

    public Cart removeItem(String owner, Long itemId) {
        Cart cart = getOrCreateCart(owner);
        cart.getItems().removeIf(item -> item.getId().equals(itemId));
        return cartRepo.save(cart);
    }

    public Cart clearCart(String owner) {
        Cart cart = getOrCreateCart(owner);
        cart.getItems().clear();
        return cartRepo.save(cart);
    }
}
