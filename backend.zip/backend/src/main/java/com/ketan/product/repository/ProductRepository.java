package com.ketan.product.repository;

import com.ketan.product.model.Product;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long>, JpaSpecificationExecutor<Product> {
	List<Product> findByApprovedTrue();
	List<Product> findByApprovedFalse();

	@Query("SELECT p FROM Product p WHERE p.approved = true AND " +
		   "(:q IS NULL OR (LOWER(p.name) LIKE LOWER(CONCAT('%',:q,'%')) OR LOWER(p.description) LIKE LOWER(CONCAT('%',:q,'%')) OR LOWER(p.sku) LIKE LOWER(CONCAT('%',:q,'%')))) AND " +
		   "(:min IS NULL OR p.price >= :min) AND (:max IS NULL OR p.price <= :max)")
	Page<Product> search(@Param("q") String q, @Param("min") BigDecimal min, @Param("max") BigDecimal max, Pageable pageable);
}
