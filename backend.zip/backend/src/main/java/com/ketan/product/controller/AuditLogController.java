package com.ketan.product.controller;

import com.ketan.product.exception.UnauthorizedException;
import com.ketan.product.model.AuditLog;
import com.ketan.product.service.AuditLogService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Admin endpoints for viewing audit logs and user-interest analytics.
 *
 * All endpoints require ADMIN role except /api/audit/my-activity which
 * lets any authenticated user see their own audit trail.
 */
@RestController
@RequestMapping("/api/audit")
public class AuditLogController {

    private final AuditLogService auditLogService;

    public AuditLogController(AuditLogService auditLogService) {
        this.auditLogService = auditLogService;
    }

    // ─── Paginated log queries ───────────────────────────────────────────

    /** List all audit logs (paginated, most recent first). */
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping
    public Page<AuditLog> all(Pageable pageable) {
        return auditLogService.findAll(pageable);
    }

    /** Filter logs by username. */
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/user/{username}")
    public Page<AuditLog> byUser(@PathVariable String username, Pageable pageable) {
        return auditLogService.findByUser(username, pageable);
    }

    /** Filter logs by category (e.g. CART, PRODUCT_DETAIL, ORDER). */
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/category/{category}")
    public Page<AuditLog> byCategory(@PathVariable String category, Pageable pageable) {
        return auditLogService.findByCategory(category, pageable);
    }

    /** Filter logs by specific action (e.g. ADD_TO_CART, LOGIN). */
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/action/{action}")
    public Page<AuditLog> byAction(@PathVariable String action, Pageable pageable) {
        return auditLogService.findByAction(action, pageable);
    }

    /** Filter logs by date range. */
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/range")
    public Page<AuditLog> byDateRange(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime to,
            Pageable pageable) {
        return auditLogService.findByDateRange(from, to, pageable);
    }

    /** View all failed actions (security monitoring). */
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/failures")
    public Page<AuditLog> failures(Pageable pageable) {
        return auditLogService.findFailures(pageable);
    }

    // ─── User interest / analytics ───────────────────────────────────────

    /**
     * Returns a summary of a user's interests based on their audit categories.
     * Example response: { "PRODUCT_DETAIL": 42, "CATALOG_SEARCH": 18, "CART": 12, ... }
     */
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/interest/{username}")
    public ResponseEntity<Map<String, Object>> userInterest(@PathVariable String username) {
        Map<String, Object> result = new HashMap<>();
        result.put("username", username);
        result.put("categoryCounts", auditLogService.userInterestSummary(username));
        result.put("actionCounts", auditLogService.userActionSummary(username));
        return ResponseEntity.ok(result);
    }

    /** Top viewed products across all users. */
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/analytics/top-products")
    public List<Map<String, Object>> topProducts(@RequestParam(defaultValue = "20") int limit) {
        return auditLogService.mostViewedProducts(limit);
    }

    /** Top searched terms across all users. */
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/analytics/top-searches")
    public List<Map<String, Object>> topSearches(@RequestParam(defaultValue = "20") int limit) {
        return auditLogService.mostSearchedTerms(limit);
    }

    /** Global summary – count per category. */
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/analytics/summary")
    public Map<String, Long> summary() {
        return auditLogService.categorySummary();
    }

    // ─── Self-service: any authenticated user can see their own activity ─

    /** Current user's own activity log. */
    @GetMapping("/my-activity")
    public Page<AuditLog> myActivity(Authentication auth, Pageable pageable) {
        if (auth == null) throw new UnauthorizedException();
        return auditLogService.findByUser(auth.getName(), pageable);
    }

    /** Current user's own interest summary. */
    @GetMapping("/my-interest")
    public Map<String, Object> myInterest(Authentication auth) {
        if (auth == null) throw new UnauthorizedException();
        Map<String, Object> result = new HashMap<>();
        result.put("categoryCounts", auditLogService.userInterestSummary(auth.getName()));
        result.put("actionCounts", auditLogService.userActionSummary(auth.getName()));
        return result;
    }
}
