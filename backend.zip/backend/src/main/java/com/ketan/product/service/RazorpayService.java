package com.ketan.product.service;

import com.razorpay.Order;
import com.razorpay.Payment;
import com.razorpay.Refund;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import com.razorpay.Utils;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@Service
public class RazorpayService {

    private static final Logger log = LoggerFactory.getLogger(RazorpayService.class);

    @Value("${razorpay.key-id:}")
    private String keyId;

    @Value("${razorpay.key-secret:}")
    private String keySecret;

    private RazorpayClient client;

    @PostConstruct
    public void init() {
        if (isConfigured()) {
            try {
                this.client = new RazorpayClient(keyId, keySecret);
            } catch (RazorpayException e) {
                System.err.println("Failed to initialize RazorpayClient: " + e.getMessage());
            }
        }
    }

    public boolean isConfigured() {
        return keyId != null && !keyId.isBlank() && keySecret != null && !keySecret.isBlank();
    }

    public String getKeyId() {
        return keyId;
    }

    /**
     * Create a Razorpay order. Amount is in rupees — converted to paise for the API.
     */
    public Map<String, Object> createOrder(BigDecimal amount, String currency, String receipt) throws RazorpayException {
        if (client == null) {
            throw new RazorpayException("Razorpay client not initialized. Check your key-id and key-secret.");
        }

        // Razorpay expects amount in smallest currency unit (paise for INR)
        int amountInPaise = amount.multiply(BigDecimal.valueOf(100)).intValue();

        JSONObject options = new JSONObject();
        options.put("amount", amountInPaise);
        options.put("currency", currency);
        options.put("receipt", receipt);
        options.put("payment_capture", 1); // auto-capture

        Order order = client.orders.create(options);

        Map<String, Object> resp = new HashMap<>();
        resp.put("id", order.get("id"));
        resp.put("amount", order.get("amount"));
        resp.put("currency", order.get("currency"));
        resp.put("receipt", order.get("receipt"));
        resp.put("status", order.get("status"));
        return resp;
    }

    /**
     * Verify payment signature using Razorpay utility.
     * Returns true if the signature is valid.
     */
    public boolean verifySignature(String razorpayOrderId, String razorpayPaymentId, String razorpaySignature) {
        try {
            JSONObject attributes = new JSONObject();
            attributes.put("razorpay_order_id", razorpayOrderId);
            attributes.put("razorpay_payment_id", razorpayPaymentId);
            attributes.put("razorpay_signature", razorpaySignature);
            return Utils.verifyPaymentSignature(attributes, keySecret);
        } catch (RazorpayException e) {
            log.error("Signature verification failed: {}", e.getMessage());
            return false;
        }
    }

    /**
     * Fetch full payment details from Razorpay by payment ID.
     * Returns all fields: method, bank, vpa, utr, rrn, card info, fee, tax, etc.
     */
    public Map<String, Object> fetchPaymentDetails(String razorpayPaymentId) throws RazorpayException {
        if (client == null) {
            throw new RazorpayException("Razorpay client not initialized.");
        }

        Payment payment = client.payments.fetch(razorpayPaymentId);

        Map<String, Object> details = new HashMap<>();
        details.put("method", safeGet(payment, "method"));
        details.put("bank", safeGet(payment, "bank"));
        details.put("wallet", safeGet(payment, "wallet"));
        details.put("vpa", safeGet(payment, "vpa"));
        details.put("email", safeGet(payment, "email"));
        details.put("contact", safeGet(payment, "contact"));
        details.put("fee", safeGetInt(payment, "fee"));
        details.put("tax", safeGetInt(payment, "tax"));
        details.put("international", safeGetBool(payment, "international"));
        details.put("error_code", safeGet(payment, "error_code"));
        details.put("error_description", safeGet(payment, "error_description"));
        details.put("error_reason", safeGet(payment, "error_reason"));

        // Card details (nested object)
        try {
            JSONObject card = payment.get("card");
            if (card != null) {
                details.put("card_id", card.optString("id", null));
                details.put("card_last4", card.optString("last4", null));
                details.put("card_network", card.optString("network", null));
                details.put("card_type", card.optString("type", null));
            }
        } catch (Exception e) {
            log.debug("No card details for payment {}", razorpayPaymentId);
        }

        // Acquirer data (UTR, RRN, auth_code)
        try {
            JSONObject acquirer = payment.get("acquirer_data");
            if (acquirer != null) {
                details.put("utr", acquirer.optString("utr", acquirer.optString("bank_transaction_id", null)));
                details.put("rrn", acquirer.optString("rrn", null));
                details.put("auth_code", acquirer.optString("authentication_reference_number",
                        acquirer.optString("auth_code", null)));
            }
        } catch (Exception e) {
            log.debug("No acquirer data for payment {}", razorpayPaymentId);
        }

        return details;
    }

    /**
     * Initiate a refund via Razorpay.
     * @param razorpayPaymentId the Razorpay payment ID to refund
     * @param amountInRupees    refund amount in rupees (null = full refund)
     * @param reason            reason for refund
     * @return map with refund id, status, amount
     */
    public Map<String, Object> initiateRefund(String razorpayPaymentId, BigDecimal amountInRupees, String reason) throws RazorpayException {
        if (client == null) {
            throw new RazorpayException("Razorpay client not initialized.");
        }

        JSONObject options = new JSONObject();
        if (amountInRupees != null) {
            options.put("amount", amountInRupees.multiply(BigDecimal.valueOf(100)).intValue());
        }
        if (reason != null && !reason.isBlank()) {
            options.put("notes", new JSONObject().put("reason", reason));
        }
        options.put("speed", "normal");

        Refund refund = client.payments.refund(razorpayPaymentId, options);

        Map<String, Object> result = new HashMap<>();
        result.put("refund_id", safeGet(refund, "id"));
        result.put("amount", safeGetInt(refund, "amount"));
        result.put("status", safeGet(refund, "status"));
        result.put("speed_requested", safeGet(refund, "speed_requested"));
        result.put("speed_processed", safeGet(refund, "speed_processed"));
        return result;
    }

    // ─── Helper methods for safe JSON extraction ─────────────────────────

    private String safeGet(com.razorpay.Entity entity, String key) {
        try {
            Object val = entity.get(key);
            return val != null && !val.toString().equals("null") ? val.toString() : null;
        } catch (Exception e) { return null; }
    }

    private Integer safeGetInt(com.razorpay.Entity entity, String key) {
        try {
            Object val = entity.get(key);
            if (val == null || val.toString().equals("null")) return null;
            return val instanceof Number ? ((Number) val).intValue() : Integer.parseInt(val.toString());
        } catch (Exception e) { return null; }
    }

    private Boolean safeGetBool(com.razorpay.Entity entity, String key) {
        try {
            Object val = entity.get(key);
            if (val == null || val.toString().equals("null")) return null;
            return val instanceof Boolean ? (Boolean) val : Boolean.parseBoolean(val.toString());
        } catch (Exception e) { return null; }
    }
}
