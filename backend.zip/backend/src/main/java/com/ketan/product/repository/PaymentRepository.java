package com.ketan.product.repository;

import com.ketan.product.model.Payment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
    Optional<Payment> findByRazorpayOrderId(String razorpayOrderId);
    Optional<Payment> findByOrderId(Long orderId);
    List<Payment> findByStatus(String status);
    Optional<Payment> findByRazorpayPaymentId(String razorpayPaymentId);
    List<Payment> findByUserId(Long userId);
    List<Payment> findByUsername(String username);
    Optional<Payment> findByRefundId(String refundId);
    List<Payment> findByMethod(String method);
    List<Payment> findByUtr(String utr);
}
