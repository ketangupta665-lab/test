package com.ketan.product.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * Persisted audit log entry – captures every user action for analytics,
 * security review, and understanding user interest / behaviour.
 */
@Entity
@Table(name = "audit_logs", indexes = {
        @Index(name = "idx_audit_username", columnList = "username"),
        @Index(name = "idx_audit_category", columnList = "category"),
        @Index(name = "idx_audit_timestamp", columnList = "timestamp"),
        @Index(name = "idx_audit_action", columnList = "action")
})
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Who performed the action (username or "anonymous"). */
    @Column(nullable = false)
    private String username;

    /**
     * High-level category for grouping / interest analysis.
     * Examples: AUTH, CATALOG_VIEW, CATALOG_SEARCH, PRODUCT_DETAIL,
     *           CART, CHECKOUT, ORDER, PAYMENT, PROFILE, ADDRESS,
     *           ADMIN, INVOICE, OTP, OAUTH
     */
    @Column(nullable = false, length = 40)
    private String category;

    /**
     * Specific action performed.
     * Examples: LOGIN, LOGOUT, VIEW_PRODUCTS, SEARCH_PRODUCTS,
     *           VIEW_PRODUCT_DETAIL, ADD_TO_CART, REMOVE_FROM_CART,
     *           CHECKOUT, CREATE_ORDER, MAKE_PAYMENT, VERIFY_PAYMENT,
     *           VIEW_PROFILE, UPDATE_PROFILE, ADD_ADDRESS, DELETE_ADDRESS,
     *           ADMIN_UPDATE_STOCK, ADMIN_APPROVE_PRODUCT, etc.
     */
    @Column(nullable = false, length = 60)
    private String action;

    /** HTTP method (GET, POST, PUT, DELETE). */
    @Column(length = 10)
    private String httpMethod;

    /** The request URI (e.g. /api/catalog/5). */
    @Column(length = 500)
    private String endpoint;

    /** Optional resource type involved (Product, Order, etc.). */
    @Column(length = 40)
    private String resourceType;

    /** Optional resource id involved. */
    private Long resourceId;

    /** Arbitrary detail / description (e.g. search query, product name). */
    @Column(length = 1000)
    private String details;

    /** Client IP address. */
    @Column(length = 45)
    private String ipAddress;

    /** User-Agent header value (truncated). */
    @Column(length = 500)
    private String userAgent;

    /** Whether the action succeeded or failed. */
    @Column(nullable = false)
    private boolean success = true;

    /** Error message if the action failed. */
    @Column(length = 500)
    private String errorMessage;

    /** Timestamp of the action. */
    @Column(nullable = false)
    private LocalDateTime timestamp;

    /** How long the action took in milliseconds. */
    private Long durationMs;

    public AuditLog() {
        this.timestamp = LocalDateTime.now();
    }

    // ── Getters & Setters ────────────────────────────────────────────────

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }

    public String getHttpMethod() { return httpMethod; }
    public void setHttpMethod(String httpMethod) { this.httpMethod = httpMethod; }

    public String getEndpoint() { return endpoint; }
    public void setEndpoint(String endpoint) { this.endpoint = endpoint; }

    public String getResourceType() { return resourceType; }
    public void setResourceType(String resourceType) { this.resourceType = resourceType; }

    public Long getResourceId() { return resourceId; }
    public void setResourceId(Long resourceId) { this.resourceId = resourceId; }

    public String getDetails() { return details; }
    public void setDetails(String details) { this.details = details; }

    public String getIpAddress() { return ipAddress; }
    public void setIpAddress(String ipAddress) { this.ipAddress = ipAddress; }

    public String getUserAgent() { return userAgent; }
    public void setUserAgent(String userAgent) { this.userAgent = userAgent; }

    public boolean isSuccess() { return success; }
    public void setSuccess(boolean success) { this.success = success; }

    public String getErrorMessage() { return errorMessage; }
    public void setErrorMessage(String errorMessage) { this.errorMessage = errorMessage; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }

    public Long getDurationMs() { return durationMs; }
    public void setDurationMs(Long durationMs) { this.durationMs = durationMs; }
}
