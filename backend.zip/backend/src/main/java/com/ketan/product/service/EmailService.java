package com.ketan.product.service;

import com.ketan.product.model.OrderEntity;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.lang.Nullable;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class EmailService {
    private final Logger log = LoggerFactory.getLogger(EmailService.class);

    private final JavaMailSender mailSender; // may be null if SMTP not configured

    public EmailService(@Nullable JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    @Value("${email.from:no-reply@example.com}")
    private String fromAddress;

    public void sendSimpleEmail(String to, String subject, String bodyText) {
        if (mailSender == null) {
            log.info("SMTP not configured - email to {} skipped (subject={})", to, subject);
            return;
        }
        try {
            SimpleMailMessage msg = new SimpleMailMessage();
            msg.setFrom(fromAddress);
            msg.setTo(to);
            msg.setSubject(subject);
            msg.setText(bodyText);
            mailSender.send(msg);
            log.info("Sent email to {} via SMTP", to);
        } catch (Exception e) {
            log.error("SMTP send failed: {}", e.getMessage());
        }
    }

    public void sendHtmlEmail(String to, String subject, String htmlBody) {
        if (mailSender == null) {
            log.info("SMTP not configured - HTML email to {} skipped (subject={})", to, subject);
            return;
        }
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");
            helper.setFrom(fromAddress);
            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(htmlBody, true);
            mailSender.send(message);
            log.info("Sent HTML email to {} via SMTP (subject={})", to, subject);
        } catch (MessagingException e) {
            log.error("SMTP HTML send failed: {}", e.getMessage());
        }
    }

    @Async
    public void sendOrderConfirmation(String toEmail, String customerName, OrderEntity order) {
        if (toEmail == null || toEmail.isBlank()) {
            log.warn("Cannot send order confirmation — no email for order #{}", order.getId());
            return;
        }

        String name = (customerName != null && !customerName.isBlank()) ? customerName : "Customer";
        String subject = "Order Confirmed — #" + order.getId() + " | Shyamaju Store";

        BigDecimal subtotal = order.getAmount();
        BigDecimal shipping = order.getShippingCharge() != null ? order.getShippingCharge() : BigDecimal.ZERO;
        BigDecimal discount = order.getCouponDiscount() != null ? order.getCouponDiscount() : BigDecimal.ZERO;

        String html = "<!DOCTYPE html>"
                + "<html><head><meta charset='UTF-8'>"
                + "<style>"
                + "body{margin:0;padding:0;font-family:'Segoe UI',Arial,sans-serif;background:#f4f4f7;}"
                + ".wrapper{max-width:600px;margin:0 auto;background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,0.08);}"
                + ".header{background:linear-gradient(135deg,#6366f1,#8b5cf6);padding:32px 24px;text-align:center;color:#fff;}"
                + ".header h1{margin:0;font-size:24px;font-weight:700;}"
                + ".header p{margin:8px 0 0;font-size:14px;opacity:0.9;}"
                + ".check-icon{font-size:48px;margin-bottom:12px;}"
                + ".content{padding:32px 24px;}"
                + ".greeting{font-size:18px;color:#1f2937;margin:0 0 8px;}"
                + ".message{font-size:14px;color:#6b7280;margin:0 0 24px;line-height:1.6;}"
                + ".order-box{border:1px solid #e5e7eb;border-radius:10px;overflow:hidden;margin-bottom:24px;}"
                + ".order-box-header{background:#f9fafb;padding:14px 20px;border-bottom:1px solid #e5e7eb;display:flex;justify-content:space-between;}"
                + ".order-box-header span{font-size:13px;color:#6b7280;}"
                + ".order-box-header strong{font-size:14px;color:#1f2937;}"
                + ".order-row{display:flex;justify-content:space-between;padding:12px 20px;border-bottom:1px solid #f3f4f6;font-size:14px;color:#374151;}"
                + ".order-row:last-child{border-bottom:none;}"
                + ".order-row .label{color:#6b7280;}"
                + ".total-row{background:#f0fdf4;font-weight:700;font-size:16px;color:#065f46;}"
                + ".discount-row .value{color:#059669;}"
                + ".status-badge{display:inline-block;padding:6px 16px;border-radius:20px;font-size:13px;font-weight:600;background:#dbeafe;color:#1d4ed8;}"
                + ".footer{background:#f9fafb;padding:24px;text-align:center;border-top:1px solid #e5e7eb;}"
                + ".footer p{margin:0;font-size:12px;color:#9ca3af;line-height:1.6;}"
                + ".footer a{color:#6366f1;text-decoration:none;}"
                + "</style></head><body>"
                + "<div style='padding:20px;'>"
                + "<div class='wrapper'>"

                // Header
                + "<div class='header'>"
                + "<div class='check-icon'>&#10004;</div>"
                + "<h1>Order Placed Successfully!</h1>"
                + "<p>Thank you for shopping with Shyamaju Store</p>"
                + "</div>"

                // Content
                + "<div class='content'>"
                + "<p class='greeting'>Hi " + escapeHtml(name) + ",</p>"
                + "<p class='message'>Your order has been placed successfully and is being processed. "
                + "You will receive updates as your order moves through each stage.</p>"

                // Order details box
                + "<div class='order-box'>"
                + "<div class='order-box-header'>"
                + "<span>Order ID: <strong>#" + order.getId() + "</strong></span>"
                + "<span class='status-badge'>CONFIRMED</span>"
                + "</div>"

                + "<div class='order-row'><span class='label'>Items</span><span>" + order.getQuantity() + " item(s)</span></div>";

        // Coupon row
        if (order.getCouponCode() != null && !order.getCouponCode().isBlank()) {
            html += "<div class='order-row'><span class='label'>Coupon</span><span>" + escapeHtml(order.getCouponCode()) + "</span></div>";
        }
        if (discount.compareTo(BigDecimal.ZERO) > 0) {
            html += "<div class='order-row discount-row'><span class='label'>Discount</span><span class='value'>- &#8377;" + discount.toPlainString() + "</span></div>";
        }

        html += "<div class='order-row'><span class='label'>Shipping</span><span>"
                + (shipping.compareTo(BigDecimal.ZERO) == 0 ? "FREE" : "&#8377;" + shipping.toPlainString())
                + "</span></div>"
                + "<div class='order-row total-row'><span>Total</span><span>&#8377;" + subtotal.toPlainString() + "</span></div>"
                + "</div>" // end order-box

                + "<p class='message'>You can track your order status from your "
                + "<a href='#' style='color:#6366f1;text-decoration:none;font-weight:600;'>Profile &rarr; Order History</a> page.</p>"
                + "</div>" // end content

                // Footer
                + "<div class='footer'>"
                + "<p>&#127753; Shyamaju Store<br>"
                + "If you have any questions, reply to this email or contact our support.</p>"
                + "</div>"

                + "</div>" // end wrapper
                + "</div>"
                + "</body></html>";

        sendHtmlEmail(toEmail, subject, html);
    }

    private static String escapeHtml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }
}
