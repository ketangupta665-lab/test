package com.ketan.product.controller;

import com.ketan.product.exception.BadRequestException;
import com.ketan.product.exception.ResourceNotFoundException;
import com.ketan.product.model.Invoice;
import com.ketan.product.model.OrderEntity;
import com.ketan.product.model.Payment;
import com.ketan.product.model.Product;
import com.ketan.product.model.User;
import com.ketan.product.repository.InvoiceRepository;
import com.ketan.product.repository.OrderRepository;
import com.ketan.product.repository.PaymentRepository;
import com.ketan.product.repository.ProductRepository;
import com.ketan.product.repository.UserRepository;
import com.ketan.product.service.EmailService;
import com.ketan.product.service.SmsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private static final Logger log = LoggerFactory.getLogger(AdminController.class);

    private final OrderRepository orderRepo;
    private final InvoiceRepository invoiceRepo;
    private final PaymentRepository paymentRepo;
    private final ProductRepository productRepo;
    private final UserRepository userRepo;
    private final SmsService smsService;
    private final EmailService emailService;

    public AdminController(OrderRepository orderRepo, InvoiceRepository invoiceRepo,
                           PaymentRepository paymentRepo, ProductRepository productRepo,
                           UserRepository userRepo, SmsService smsService, EmailService emailService) {
        this.orderRepo = orderRepo;
        this.invoiceRepo = invoiceRepo;
        this.paymentRepo = paymentRepo;
        this.productRepo = productRepo;
        this.userRepo = userRepo;
        this.smsService = smsService;
        this.emailService = emailService;
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/orders")
    public List<OrderEntity> orders() { return orderRepo.findAll(); }

    // Update payment status for an order
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/orders/{id}/payment-status")
    public ResponseEntity<OrderEntity> updatePaymentStatus(@PathVariable Long id, @RequestBody String status) {
        return orderRepo.findById(id).map(o -> { o.setPaymentStatus(status); orderRepo.save(o); return ResponseEntity.ok(o); })
                .orElseThrow(() -> new ResourceNotFoundException("Order", "id", id));
    }

    // Update shipment status and tracking number
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/orders/{id}/shipment")
    public ResponseEntity<OrderEntity> updateShipment(@PathVariable Long id, @RequestBody OrderShipmentUpdate body) {
        return orderRepo.findById(id).map(o -> {
            String previousStatus = o.getShipmentStatus();
            if (body.getShipmentStatus() != null) o.setShipmentStatus(body.getShipmentStatus());
            if (body.getTrackingNumber() != null) o.setTrackingNumber(body.getTrackingNumber());
            orderRepo.save(o);

            // Notify customer via SMS on SHIPPED / DELIVERED transitions
            String newStatus = o.getShipmentStatus();
            if (newStatus != null && !newStatus.equalsIgnoreCase(previousStatus)
                    && o.getUser() != null && o.getUser().getPhone() != null
                    && !o.getUser().getPhone().isBlank()) {
                String phone = o.getUser().getPhone();
                if ("SHIPPED".equalsIgnoreCase(newStatus)) {
                    String track = o.getTrackingNumber() != null ? o.getTrackingNumber() : "";
                    String sms = "Shyamaju Store: Your order #" + o.getId() + " has been shipped."
                            + (track.isBlank() ? "" : " Tracking: " + track + ".")
                            + " Thank you!";
                    smsService.sendSms(phone, sms);
                } else if ("DELIVERED".equalsIgnoreCase(newStatus)) {
                    String sms = "Shyamaju Store: Your order #" + o.getId()
                            + " has been delivered. Hope you love it!";
                    smsService.sendSms(phone, sms);
                }
            }

            return ResponseEntity.ok(o);
        }).orElseThrow(() -> new ResourceNotFoundException("Order", "id", id));
    }

    // Refund order
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/orders/{id}/refund")
    public ResponseEntity<OrderEntity> refundOrder(@PathVariable Long id, @RequestBody(required = false) String reason) {
        return orderRepo.findById(id).map(o -> {
            o.setRefunded(true);
            o.setPaymentStatus("REFUNDED");
            orderRepo.save(o);
            return ResponseEntity.ok(o);
        }).orElseThrow(() -> new ResourceNotFoundException("Order", "id", id));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/invoices")
    public List<Invoice> invoices() { return invoiceRepo.findAll(); }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/invoices/{id}/detail")
    public ResponseEntity<Map<String, Object>> invoiceDetail(@PathVariable Long id) {
        return invoiceRepo.findById(id).map(inv -> {
            Map<String, Object> result = new HashMap<>();
            result.put("invoice", inv);
            // Attach order details
            if (inv.getOrderId() != null) {
                orderRepo.findById(inv.getOrderId()).ifPresent(order -> {
                    Map<String, Object> orderMap = new HashMap<>();
                    orderMap.put("id", order.getId());
                    orderMap.put("product", order.getProduct());
                    orderMap.put("quantity", order.getQuantity());
                    orderMap.put("amount", order.getAmount());
                    orderMap.put("paymentStatus", order.getPaymentStatus());
                    orderMap.put("shipmentStatus", order.getShipmentStatus());
                    orderMap.put("trackingNumber", order.getTrackingNumber());
                    result.put("order", orderMap);
                    // Attach user details
                    if (order.getUser() != null) {
                        Map<String, Object> userMap = new HashMap<>();
                        userMap.put("id", order.getUser().getId());
                        userMap.put("name", order.getUser().getName());
                        userMap.put("username", order.getUser().getUsername());
                        userMap.put("email", order.getUser().getEmail());
                        userMap.put("phone", order.getUser().getPhone());
                        result.put("customer", userMap);
                        // Attach first address if available
                        if (order.getUser().getAddresses() != null && !order.getUser().getAddresses().isEmpty()) {
                            var addr = order.getUser().getAddresses().get(0);
                            Map<String, Object> addrMap = new HashMap<>();
                            addrMap.put("line1", addr.getLine1());
                            addrMap.put("line2", addr.getLine2());
                            addrMap.put("city", addr.getCity());
                            addrMap.put("state", addr.getState());
                            addrMap.put("postalCode", addr.getPostalCode());
                            addrMap.put("country", addr.getCountry());
                            result.put("address", addrMap);
                        }
                    }
                });
                // Attach payment details
                paymentRepo.findByOrderId(inv.getOrderId()).ifPresent(pay -> {
                    Map<String, Object> payMap = new HashMap<>();
                    payMap.put("id", pay.getId());
                    payMap.put("amount", pay.getAmount());
                    payMap.put("currency", pay.getCurrency());
                    payMap.put("status", pay.getStatus());
                    payMap.put("razorpayPaymentId", pay.getRazorpayPaymentId());
                    payMap.put("createdAt", pay.getCreatedAt());
                    result.put("payment", payMap);
                });
            }
            return ResponseEntity.ok(result);
        }).orElseThrow(() -> new ResourceNotFoundException("Invoice", "id", id));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/payments")
    public List<Payment> payments() { return paymentRepo.findAll(); }

    // Admin create product (immediately live)
    @PreAuthorize("hasAnyRole('ADMIN','PRODUCT_ADMIN')")
    @PostMapping("/products")
    public Product createProduct(@RequestBody Product p, org.springframework.security.core.Authentication auth) {
        // Only full ADMIN gets auto-approval; PRODUCT_ADMIN products need admin approval
        boolean isFullAdmin = auth.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
        p.setApproved(isFullAdmin);
        return productRepo.save(p);
    }

    @PreAuthorize("hasAnyRole('ADMIN','PRODUCT_ADMIN')")
    @GetMapping("/inventory")
    public List<Product> inventory() { return productRepo.findAll(); }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/products/{id}/stock")
    public ResponseEntity<Product> setStock(@PathVariable Long id, @RequestBody Integer qty) {
        return productRepo.findById(id).map(p -> { p.setStock(qty == null ? 0 : qty); productRepo.save(p); return ResponseEntity.ok(p); })
                .orElseThrow(() -> new ResourceNotFoundException("Product", "id", id));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/products/{id}/stock/adjust")
    public ResponseEntity<Product> adjustStock(@PathVariable Long id, @RequestBody Integer delta) {
        return productRepo.findById(id).map(p -> { p.setStock(Math.max(0, p.getStock() + (delta == null ? 0 : delta))); productRepo.save(p); return ResponseEntity.ok(p); })
                .orElseThrow(() -> new ResourceNotFoundException("Product", "id", id));
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/products/{id}/toggle-active")
    public ResponseEntity<Product> toggleActive(@PathVariable Long id) {
        return productRepo.findById(id).map(p -> {
            p.setApproved(!p.isApproved());
            productRepo.save(p);
            return ResponseEntity.ok(p);
        }).orElseThrow(() -> new ResourceNotFoundException("Product", "id", id));
    }

    // Update product details (name, sku, description, price, images)
    @PreAuthorize("hasAnyRole('ADMIN','PRODUCT_ADMIN')")
    @org.springframework.web.bind.annotation.PutMapping("/products/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable Long id, @RequestBody Product body) {
        return productRepo.findById(id).map(p -> {
            if (body.getName() != null)        p.setName(body.getName());
            if (body.getSku() != null)         p.setSku(body.getSku());
            if (body.getDescription() != null) p.setDescription(body.getDescription());
            if (body.getPrice() != null)       p.setPrice(body.getPrice());
            if (body.getImages() != null)      p.setImages(body.getImages());
            productRepo.save(p);
            return ResponseEntity.ok(p);
        }).orElseThrow(() -> new ResourceNotFoundException("Product", "id", id));
    }

    // ─── Campaign / Broadcast endpoints ─────────────────────────────────

    /**
     * Send SMS campaign to all users with phone numbers.
     * Body: { "message": "Sale text..." }
     */
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/campaign/sms")
    public ResponseEntity<Map<String, Object>> sendSmsCampaign(@RequestBody Map<String, String> body) {
        String message = body.get("message");
        if (message == null || message.isBlank()) {
            throw new BadRequestException("Campaign message is required");
        }

        List<User> users = userRepo.findAll();
        List<String> phones = users.stream()
                .map(User::getPhone)
                .filter(p -> p != null && !p.isBlank())
                .collect(Collectors.toList());

        if (phones.isEmpty()) {
            Map<String, Object> resp = new HashMap<>();
            resp.put("status", "no_recipients");
            resp.put("message", "No users with phone numbers found");
            resp.put("totalUsers", users.size());
            resp.put("eligibleCount", 0);
            return ResponseEntity.ok(resp);
        }

        log.info("[Campaign] SMS broadcast initiated to {} numbers by admin", phones.size());
        smsService.sendBulkSms(phones, message, null);

        Map<String, Object> resp = new HashMap<>();
        resp.put("status", "sent");
        resp.put("message", "SMS campaign dispatched");
        resp.put("totalUsers", users.size());
        resp.put("eligibleCount", phones.size());
        return ResponseEntity.ok(resp);
    }

    /**
     * Send email campaign to all users with email addresses.
     * Body: { "subject": "...", "message": "..." }
     */
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/campaign/email")
    public ResponseEntity<Map<String, Object>> sendEmailCampaign(@RequestBody Map<String, String> body) {
        String subject = body.get("subject");
        String message = body.get("message");
        if (subject == null || subject.isBlank()) throw new BadRequestException("Subject is required");
        if (message == null || message.isBlank()) throw new BadRequestException("Message is required");

        List<User> users = userRepo.findAll();
        List<User> eligible = users.stream()
                .filter(u -> u.getEmail() != null && !u.getEmail().isBlank())
                .collect(Collectors.toList());

        if (eligible.isEmpty()) {
            Map<String, Object> resp = new HashMap<>();
            resp.put("status", "no_recipients");
            resp.put("message", "No users with email addresses found");
            resp.put("totalUsers", users.size());
            resp.put("eligibleCount", 0);
            return ResponseEntity.ok(resp);
        }

        log.info("[Campaign] Email broadcast initiated to {} users by admin", eligible.size());

        // Build campaign HTML template
        String html = buildCampaignEmailHtml(subject, message);

        for (User u : eligible) {
            emailService.sendHtmlEmail(u.getEmail(), subject, html);
        }

        Map<String, Object> resp = new HashMap<>();
        resp.put("status", "sent");
        resp.put("message", "Email campaign dispatched");
        resp.put("totalUsers", users.size());
        resp.put("eligibleCount", eligible.size());
        return ResponseEntity.ok(resp);
    }

    /**
     * Preview: get audience counts for campaign planning.
     */
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/campaign/audience")
    public Map<String, Object> campaignAudience() {
        List<User> users = userRepo.findAll();
        long withPhone = users.stream().filter(u -> u.getPhone() != null && !u.getPhone().isBlank()).count();
        long withEmail = users.stream().filter(u -> u.getEmail() != null && !u.getEmail().isBlank()).count();

        Map<String, Object> resp = new HashMap<>();
        resp.put("totalUsers", users.size());
        resp.put("withPhone", withPhone);
        resp.put("withEmail", withEmail);
        return resp;
    }

    private String buildCampaignEmailHtml(String subject, String message) {
        // Convert newlines to <br> for the message body
        String htmlMessage = message.replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;").replace("\n", "<br>");

        return "<!DOCTYPE html><html><head><meta charset='UTF-8'>"
                + "<style>"
                + "body{margin:0;padding:0;font-family:'Segoe UI',Arial,sans-serif;background:#f4f4f7;}"
                + ".wrapper{max-width:600px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,0.08);}"
                + ".header{background:linear-gradient(135deg,#f59e0b,#ef4444);padding:32px 24px;text-align:center;color:#fff;}"
                + ".header h1{margin:0;font-size:22px;font-weight:700;}"
                + ".content{padding:32px 24px;font-size:15px;color:#374151;line-height:1.7;}"
                + ".footer{background:#f9fafb;padding:20px 24px;text-align:center;border-top:1px solid #e5e7eb;}"
                + ".footer p{margin:0;font-size:12px;color:#9ca3af;}"
                + "</style></head><body>"
                + "<div style='padding:20px;'><div class='wrapper'>"
                + "<div class='header'><h1>" + subject.replace("<", "&lt;") + "</h1></div>"
                + "<div class='content'>" + htmlMessage + "</div>"
                + "<div class='footer'><p>&#127753; Shyamaju Store — You are receiving this because you are a valued customer.</p></div>"
                + "</div></div></body></html>";
    }

    // DTO for shipment update
    public static class OrderShipmentUpdate {
        private String shipmentStatus;
        private String trackingNumber;
        public String getShipmentStatus() { return shipmentStatus; }
        public void setShipmentStatus(String shipmentStatus) { this.shipmentStatus = shipmentStatus; }
        public String getTrackingNumber() { return trackingNumber; }
        public void setTrackingNumber(String trackingNumber) { this.trackingNumber = trackingNumber; }
    }
}
