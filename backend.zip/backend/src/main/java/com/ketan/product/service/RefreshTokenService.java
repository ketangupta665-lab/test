package com.ketan.product.service;

import com.ketan.product.model.RefreshToken;
import com.ketan.product.repository.RefreshTokenRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Optional;
import java.util.UUID;

@Service
public class RefreshTokenService {
    private final RefreshTokenRepository repo;

    public RefreshTokenService(RefreshTokenRepository repo) { this.repo = repo; }

    @Transactional
    public RefreshToken createTokenForUser(String username, long validitySeconds){
        // remove existing tokens
        repo.deleteByUsername(username);
        RefreshToken t = new RefreshToken();
        t.setToken(UUID.randomUUID().toString());
        t.setUsername(username);
        t.setExpiryDate(Instant.now().plus(validitySeconds, ChronoUnit.SECONDS));
        return repo.save(t);
    }

    public Optional<RefreshToken> findByToken(String token){ return repo.findByToken(token); }

    @Transactional
    public void removeToken(RefreshToken token){ if(token!=null) repo.delete(token); }

    @Transactional
    public void removeByUsername(String username){ repo.deleteByUsername(username); }
}
