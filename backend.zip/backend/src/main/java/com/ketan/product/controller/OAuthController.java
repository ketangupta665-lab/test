package com.ketan.product.controller;

import com.ketan.product.model.User;
import com.ketan.product.repository.UserRepository;
import com.ketan.product.security.JwtUtil;
import com.ketan.product.service.RefreshTokenService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Map;
import java.util.UUID;

/**
 * Manual Google OAuth2 flow for the SPA + JWT architecture.
 *
 * Flow:
 * 1. Frontend links to GET /api/auth/oauth/google
 * 2. Backend redirects to Google's authorization endpoint
 * 3. Google redirects back to GET /api/auth/oauth/google/callback with ?code=...
 * 4. Backend exchanges the code for tokens, fetches user profile,
 *    creates / looks-up the local User, generates JWT + refresh cookie,
 *    and redirects back to the frontend.
 */
@RestController
@RequestMapping("/api/auth/oauth")
public class OAuthController {

    private static final Logger log = LoggerFactory.getLogger(OAuthController.class);

    @Value("${google.client-id}")
    private String clientId;

    @Value("${google.client-secret}")
    private String clientSecret;

    @Value("${google.redirect-uri}")
    private String redirectUri;

    @Value("${jwt.access-token-expiry:900000}")
    private long accessTokenExpiry;

    @Value("${jwt.refresh-token-expiry:604800}")
    private long refreshValidity;

    private final UserRepository userRepo;
    private final JwtUtil jwtUtil;
    private final RefreshTokenService refreshService;
    private final RestTemplate restTemplate = new RestTemplate();

    private static final String GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth";
    private static final String GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token";
    private static final String GOOGLE_USERINFO_URL = "https://www.googleapis.com/oauth2/v3/userinfo";

    public OAuthController(UserRepository userRepo, JwtUtil jwtUtil, RefreshTokenService refreshService) {
        this.userRepo = userRepo;
        this.jwtUtil = jwtUtil;
        this.refreshService = refreshService;
    }

    // ─── Step 1: Redirect user to Google ────────────────────────────────

    @GetMapping("/google")
    public ResponseEntity<Void> redirectToGoogle() {
        String url = GOOGLE_AUTH_URL
                + "?client_id=" + encode(clientId)
                + "&redirect_uri=" + encode(redirectUri)
                + "&response_type=code"
                + "&scope=" + encode("openid email profile")
                + "&access_type=offline"
                + "&prompt=consent";

        return ResponseEntity.status(HttpStatus.FOUND)
                .location(URI.create(url))
                .build();
    }

    // ─── Step 2: Google calls back with an authorization code ───────────

    @GetMapping("/google/callback")
    public ResponseEntity<Void> googleCallback(@RequestParam("code") String code) {
        try {
            // 2a – exchange authorization code for tokens
            Map<String, String> tokenRequest = Map.of(
                    "code", code,
                    "client_id", clientId,
                    "client_secret", clientSecret,
                    "redirect_uri", redirectUri,
                    "grant_type", "authorization_code"
            );

            @SuppressWarnings("unchecked")
            Map<String, Object> tokenResponse = restTemplate.postForObject(
                    GOOGLE_TOKEN_URL, tokenRequest, Map.class);

            if (tokenResponse == null || !tokenResponse.containsKey("access_token")) {
                log.warn("[OAuth] Google token exchange failed: no access_token in response");
                return redirectWithError("google_auth_failed");
            }

            String accessToken = (String) tokenResponse.get("access_token");

            // 2b – fetch user profile from Google
            org.springframework.http.HttpHeaders headers = new org.springframework.http.HttpHeaders();
            headers.setBearerAuth(accessToken);
            org.springframework.http.HttpEntity<Void> entity = new org.springframework.http.HttpEntity<>(headers);

            @SuppressWarnings("unchecked")
            Map<String, Object> profile = restTemplate.exchange(
                    GOOGLE_USERINFO_URL, org.springframework.http.HttpMethod.GET, entity, Map.class
            ).getBody();

            if (profile == null || !profile.containsKey("email")) {
                log.warn("[OAuth] Google profile fetch failed: no email in response");
                return redirectWithError("google_profile_failed");
            }

            String email = (String) profile.get("email");
            String name  = (String) profile.getOrDefault("name", email);
            String sub   = (String) profile.get("sub"); // Google unique id

            // 2c – find or create user
            User user = userRepo.findByEmail(email).orElseGet(() -> {
                User u = new User();
                u.setEmail(email);
                u.setUsername(email);                       // use email as username
                u.setName(name);
                u.setPassword(UUID.randomUUID().toString()); // random password (never used)
                u.setRoles("ROLE_USER");
                u.setProvider("GOOGLE");
                u.setProviderId(sub);
                return userRepo.save(u);
            });

            // if existing user was LOCAL, link Google provider
            if ("LOCAL".equals(user.getProvider()) && sub != null) {
                user.setProvider("GOOGLE");
                user.setProviderId(sub);
                userRepo.save(user);
            }

            // 2d – issue our own JWT + refresh cookie
            String roles = user.getRoles() != null ? user.getRoles() : "ROLE_USER";
            String jwt = jwtUtil.generateToken(user.getUsername(), roles, accessTokenExpiry);
            var refresh = refreshService.createTokenForUser(user.getUsername(), refreshValidity);

            ResponseCookie cookie = ResponseCookie.from("refreshToken", refresh.getToken())
                    .httpOnly(true)
                    .path("/api/auth")
                    .maxAge(Duration.ofSeconds(refreshValidity))
                    .sameSite("Lax")
                    .build();

            // 2e – redirect to frontend with the JWT as a query parameter
            String frontendUrl = "/?token=" + jwt;

            return ResponseEntity.status(HttpStatus.FOUND)
                    .header(HttpHeaders.SET_COOKIE, cookie.toString())
                    .location(URI.create(frontendUrl))
                    .build();

        } catch (Exception e) {
            log.error("[OAuth] Google OAuth callback failed: {}", e.getMessage(), e);
            return redirectWithError("google_auth_error");
        }
    }

    private ResponseEntity<Void> redirectWithError(String errorCode) {
        return ResponseEntity.status(HttpStatus.FOUND)
                .location(URI.create("/?error=" + errorCode))
                .build();
    }

    // ─── Utilities ──────────────────────────────────────────────────────

    private static String encode(String v) {
        return URLEncoder.encode(v, StandardCharsets.UTF_8);
    }
}
