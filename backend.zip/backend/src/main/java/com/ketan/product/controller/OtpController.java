package com.ketan.product.controller;

import com.ketan.product.exception.BadRequestException;
import com.ketan.product.exception.UnauthorizedException;
import com.ketan.product.model.User;
import com.ketan.product.repository.UserRepository;
import com.ketan.product.security.JwtUtil;
import com.ketan.product.service.OtpService;
import com.ketan.product.service.RefreshTokenService;
import com.ketan.product.service.SmsService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Duration;
import java.util.Map;
import java.util.UUID;

/**
 * Passwordless OTP login.
 *
 * POST /api/auth/otp/request  { "contact": "email-or-phone" }
 * POST /api/auth/otp/verify   { "contact": "email-or-phone", "code": "123456" }
 *
 * The OTP is printed to the backend console log (no real SMS/email provider required for dev).
 */
@RestController
@RequestMapping("/api/auth/otp")
public class OtpController {

    private final OtpService otpService;
    private final UserRepository userRepo;
    private final JwtUtil jwtUtil;
    private final RefreshTokenService refreshService;
    private final SmsService smsService;

    @Value("${jwt.access-token-expiry:900000}")
    private long accessTokenExpiry;

    @Value("${jwt.refresh-token-expiry:604800}")
    private long refreshValidity;

    public OtpController(OtpService otpService, UserRepository userRepo,
                          JwtUtil jwtUtil, RefreshTokenService refreshService,
                          SmsService smsService) {
        this.otpService = otpService;
        this.userRepo = userRepo;
        this.jwtUtil = jwtUtil;
        this.refreshService = refreshService;
        this.smsService = smsService;
    }

    // ── Request OTP ──────────────────────────────────────────────────────

    public static class OtpRequest { public String contact; }

    @PostMapping("/request")
    public ResponseEntity<?> requestOtp(@RequestBody OtpRequest req) {
        if (req.contact == null || req.contact.isBlank()) {
            throw new BadRequestException("Contact (email or phone) is required");
        }

        String contact = req.contact.trim();

        // Generate & store OTP (logged to console)
        String code = otpService.generateOtp(contact);

        // Dispatch via SMS when contact is a phone number (no '@').
        // Email dispatch for email contacts is left to EmailService callers.
        boolean isPhone = !contact.contains("@");
        if (isPhone) {
            smsService.sendOtp(contact, code);
        }

        return ResponseEntity.ok(Map.of(
            "status", "OTP_SENT",
            "message", "OTP has been sent to " + contact
        ));
    }

    // ── Verify OTP & issue JWT ───────────────────────────────────────────

    public static class OtpVerify { public String contact; public String code; }

    @PostMapping("/verify")
    public ResponseEntity<?> verifyOtp(@RequestBody OtpVerify req) {
        if (req.contact == null || req.code == null) {
            throw new BadRequestException("Both contact and OTP code are required");
        }

        String contact = req.contact.trim();

        if (!otpService.verifyOtp(contact, req.code)) {
            throw new UnauthorizedException("Invalid or expired OTP");
        }

        // Look up user by email or phone; create if not found (auto-register)
        User user = findOrCreateUser(contact);

        // Issue JWT + refresh cookie (same as normal login)
        String roles = user.getRoles() != null ? user.getRoles() : "ROLE_USER";
        String accessToken = jwtUtil.generateToken(user.getUsername(), roles, accessTokenExpiry);
        var refresh = refreshService.createTokenForUser(user.getUsername(), refreshValidity);

        ResponseCookie cookie = ResponseCookie.from("refreshToken", refresh.getToken())
                .httpOnly(true)
                .path("/api/auth")
                .maxAge(Duration.ofSeconds(refreshValidity))
                .sameSite("Lax")
                .build();

        return ResponseEntity.ok()
                .header(HttpHeaders.SET_COOKIE, cookie.toString())
                .body(Map.of("token", accessToken));
    }

    // ── Helpers ──────────────────────────────────────────────────────────

    private User findOrCreateUser(String contact) {
        boolean isEmail = contact.contains("@");

        if (isEmail) {
            return userRepo.findByEmail(contact)
                    .or(() -> userRepo.findByUsername(contact))
                    .orElseGet(() -> createUser(contact, contact, null));
        } else {
            // treat as phone number
            return userRepo.findByPhone(contact)
                    .orElseGet(() -> createUser(contact, contact, contact));
        }
    }

    private User createUser(String username, String email, String phone) {
        User u = new User();
        u.setUsername(username);
        u.setPassword(UUID.randomUUID().toString()); // random (not usable)
        u.setRoles("ROLE_USER");
        if (email != null && email.contains("@")) {
            u.setEmail(email);
        }
        if (phone != null) {
            u.setPhone(phone);
        }
        u.setProvider("OTP");
        return userRepo.save(u);
    }
}
