package com.ketan.product.controller;

import com.ketan.product.exception.ResourceNotFoundException;
import com.ketan.product.exception.UnauthorizedException;
import com.ketan.product.model.OrderEntity;
import com.ketan.product.model.User;
import com.ketan.product.repository.OrderRepository;
import com.ketan.product.repository.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {
    private final OrderRepository repo;
    private final UserRepository userRepo;

    public OrderController(OrderRepository repo, UserRepository userRepo) { this.repo = repo; this.userRepo = userRepo; }

    @GetMapping
    public List<OrderEntity> all() { return repo.findAll(); }

    @GetMapping("/{id}")
    public ResponseEntity<OrderEntity> get(@PathVariable Long id) {
        OrderEntity order = repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order", "id", id));
        return ResponseEntity.ok(order);
    }

    @PostMapping
    public OrderEntity create(@RequestBody OrderEntity order) { return repo.save(order); }

    // List current user's orders
    @GetMapping("/mine")
    public ResponseEntity<List<OrderEntity>> myOrders(Authentication auth) {
        if (auth == null) throw new UnauthorizedException();
        return ResponseEntity.ok(repo.findByUserUsername(auth.getName()));
    }

    // Create order for authenticated user
    @PostMapping("/mine")
    public ResponseEntity<OrderEntity> createForMe(Authentication auth, @RequestBody OrderEntity order) {
        if (auth == null) throw new UnauthorizedException();
        User user = userRepo.findByUsername(auth.getName())
                .orElseThrow(() -> new ResourceNotFoundException("User", "username", auth.getName()));
        order.setUser(user);
        return ResponseEntity.ok(repo.save(order));
    }
}
