package com.ketan.product.data;

import com.ketan.product.model.Product;
import com.ketan.product.model.User;
import com.ketan.product.repository.ProductRepository;
import com.ketan.product.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.math.BigDecimal;

@Configuration
public class DataLoader {
    @Bean
    CommandLineRunner seed(ProductRepository repo, UserRepository userRepo, PasswordEncoder encoder) {
        return args -> {
            if (repo.count() == 0) {
                Product p1 = new Product();
                p1.setSku("P-001"); p1.setName("Widget"); p1.setDescription("A useful widget"); p1.setPrice(new BigDecimal("9.99"));
                p1.setApproved(true); p1.setStock(50);
                Product p2 = new Product();
                p2.setSku("P-002"); p2.setName("Gadget"); p2.setDescription("A helpful gadget"); p2.setPrice(new BigDecimal("19.99"));
                p2.setApproved(true); p2.setStock(30);
                repo.save(p1); repo.save(p2);
            }

            // Approve any existing unapproved seed products and set stock
            for (Product p : repo.findByApprovedFalse()) {
                p.setApproved(true);
                if (p.getStock() == 0) p.setStock(10);
                repo.save(p);
            }

            // create an admin user for initial testing if not present
            if (userRepo.count() == 0 || userRepo.findByUsername("admin").isEmpty()) {
                User admin = new User();
                admin.setUsername("admin");
                admin.setPassword(encoder.encode("adminpass"));
                admin.setName("Administrator");
                admin.setRoles("ROLE_ADMIN,ROLE_USER");
                userRepo.save(admin);
            }
        };
    }
}
