package com.ketan.product.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long orderId;
    private BigDecimal amount;
    private String currency;
    private String status; // CREATED, PAID, FAILED, REFUNDED

    // ─── Razorpay core fields ────────────────────────────────────────────
    private String razorpayOrderId;
    private String razorpayPaymentId;
    private String razorpaySignature;

    // ─── Payment method details (fetched from Razorpay after verification) ─
    private String method;          // card, netbanking, wallet, upi, emi, etc.
    private String bank;            // bank code for netbanking (e.g. HDFC, ICIC)
    private String wallet;          // wallet name (e.g. paytm, phonepe)
    private String vpa;             // UPI VPA (e.g. user@upi)
    private String cardId;          // Razorpay tokenised card id
    private String cardLast4;       // last 4 digits of card
    private String cardNetwork;     // Visa, Mastercard, Rupay, etc.
    private String cardType;        // credit / debit
    private Boolean international;  // true if international payment

    // ─── Transaction reference numbers (critical for support & refunds) ────
    private String utr;             // bank UTR / acquirer reference
    private String rrn;             // Retrieval Reference Number
    private String authCode;        // bank authorization code

    // ─── Razorpay fee & tax ───────────────────────────────────────────────
    private Integer razorpayFee;    // Razorpay fee in paise
    private Integer razorpayTax;    // GST on fee in paise

    // ─── Payer info (from gateway) ────────────────────────────────────────
    private String payerEmail;
    private String payerContact;

    // ─── Error details (populated on failure) ─────────────────────────────
    private String errorCode;
    private String errorDescription;
    private String errorReason;

    // ─── Refund fields ────────────────────────────────────────────────────
    private String refundId;            // Razorpay refund id (rfnd_...)
    private BigDecimal refundAmount;    // amount refunded
    private String refundStatus;        // created, processed, failed
    private String refundReason;        // reason for refund
    private LocalDateTime refundedAt;

    // ─── User / client info ──────────────────────────────────────────────
    private Long userId;            // app user who initiated payment
    private String username;        // username at time of payment
    private String ipAddress;       // client IP address
    private String userAgent;       // browser / device user-agent string

    // ─── Timestamps ───────────────────────────────────────────────────────
    private LocalDateTime paidAt;       // when payment was captured
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public Payment() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        this.currency = "INR";
        this.status = "CREATED";
    }

    @PreUpdate
    public void onUpdate() { this.updatedAt = LocalDateTime.now(); }

    // ─── Getters & Setters ──────────────────────────────────────────────

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getOrderId() { return orderId; }
    public void setOrderId(Long orderId) { this.orderId = orderId; }
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getRazorpayOrderId() { return razorpayOrderId; }
    public void setRazorpayOrderId(String razorpayOrderId) { this.razorpayOrderId = razorpayOrderId; }
    public String getRazorpayPaymentId() { return razorpayPaymentId; }
    public void setRazorpayPaymentId(String razorpayPaymentId) { this.razorpayPaymentId = razorpayPaymentId; }
    public String getRazorpaySignature() { return razorpaySignature; }
    public void setRazorpaySignature(String razorpaySignature) { this.razorpaySignature = razorpaySignature; }

    public String getMethod() { return method; }
    public void setMethod(String method) { this.method = method; }
    public String getBank() { return bank; }
    public void setBank(String bank) { this.bank = bank; }
    public String getWallet() { return wallet; }
    public void setWallet(String wallet) { this.wallet = wallet; }
    public String getVpa() { return vpa; }
    public void setVpa(String vpa) { this.vpa = vpa; }
    public String getCardId() { return cardId; }
    public void setCardId(String cardId) { this.cardId = cardId; }
    public String getCardLast4() { return cardLast4; }
    public void setCardLast4(String cardLast4) { this.cardLast4 = cardLast4; }
    public String getCardNetwork() { return cardNetwork; }
    public void setCardNetwork(String cardNetwork) { this.cardNetwork = cardNetwork; }
    public String getCardType() { return cardType; }
    public void setCardType(String cardType) { this.cardType = cardType; }
    public Boolean getInternational() { return international; }
    public void setInternational(Boolean international) { this.international = international; }

    public String getUtr() { return utr; }
    public void setUtr(String utr) { this.utr = utr; }
    public String getRrn() { return rrn; }
    public void setRrn(String rrn) { this.rrn = rrn; }
    public String getAuthCode() { return authCode; }
    public void setAuthCode(String authCode) { this.authCode = authCode; }

    public Integer getRazorpayFee() { return razorpayFee; }
    public void setRazorpayFee(Integer razorpayFee) { this.razorpayFee = razorpayFee; }
    public Integer getRazorpayTax() { return razorpayTax; }
    public void setRazorpayTax(Integer razorpayTax) { this.razorpayTax = razorpayTax; }

    public String getPayerEmail() { return payerEmail; }
    public void setPayerEmail(String payerEmail) { this.payerEmail = payerEmail; }
    public String getPayerContact() { return payerContact; }
    public void setPayerContact(String payerContact) { this.payerContact = payerContact; }

    public String getErrorCode() { return errorCode; }
    public void setErrorCode(String errorCode) { this.errorCode = errorCode; }
    public String getErrorDescription() { return errorDescription; }
    public void setErrorDescription(String errorDescription) { this.errorDescription = errorDescription; }
    public String getErrorReason() { return errorReason; }
    public void setErrorReason(String errorReason) { this.errorReason = errorReason; }

    public String getRefundId() { return refundId; }
    public void setRefundId(String refundId) { this.refundId = refundId; }
    public BigDecimal getRefundAmount() { return refundAmount; }
    public void setRefundAmount(BigDecimal refundAmount) { this.refundAmount = refundAmount; }
    public String getRefundStatus() { return refundStatus; }
    public void setRefundStatus(String refundStatus) { this.refundStatus = refundStatus; }
    public String getRefundReason() { return refundReason; }
    public void setRefundReason(String refundReason) { this.refundReason = refundReason; }
    public LocalDateTime getRefundedAt() { return refundedAt; }
    public void setRefundedAt(LocalDateTime refundedAt) { this.refundedAt = refundedAt; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getIpAddress() { return ipAddress; }
    public void setIpAddress(String ipAddress) { this.ipAddress = ipAddress; }
    public String getUserAgent() { return userAgent; }
    public void setUserAgent(String userAgent) { this.userAgent = userAgent; }

    public LocalDateTime getPaidAt() { return paidAt; }
    public void setPaidAt(LocalDateTime paidAt) { this.paidAt = paidAt; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}
