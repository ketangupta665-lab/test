package com.ketan.product.service;

import com.ketan.product.model.AuditLog;
import com.ketan.product.repository.AuditLogRepository;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Service for recording and querying audit logs.
 * All log writes are @Async so they never slow down the user request.
 */
@Service
public class AuditLogService {

    private static final Logger log = LoggerFactory.getLogger(AuditLogService.class);
    private final AuditLogRepository repo;

    public AuditLogService(AuditLogRepository repo) {
        this.repo = repo;
    }

    // ─── Write helpers ───────────────────────────────────────────────────

    /**
     * Log a successful action – call from controllers or aspect.
     */
    @Async
    public void logAction(String category, String action, String resourceType,
                          Long resourceId, String details, long durationMs) {
        try {
            AuditLog entry = buildEntry(category, action, resourceType, resourceId, details, durationMs);
            entry.setSuccess(true);
            repo.save(entry);
        } catch (Exception e) {
            log.warn("Failed to persist audit log: {}", e.getMessage());
        }
    }

    /**
     * Log a failed action.
     */
    @Async
    public void logFailure(String category, String action, String resourceType,
                           Long resourceId, String details, String errorMessage, long durationMs) {
        try {
            AuditLog entry = buildEntry(category, action, resourceType, resourceId, details, durationMs);
            entry.setSuccess(false);
            entry.setErrorMessage(truncate(errorMessage, 500));
            repo.save(entry);
        } catch (Exception e) {
            log.warn("Failed to persist audit log: {}", e.getMessage());
        }
    }

    /**
     * Simple convenience overload for actions with no resource id.
     */
    @Async
    public void logAction(String category, String action, String details) {
        logAction(category, action, null, null, details, 0);
    }

    private AuditLog buildEntry(String category, String action, String resourceType,
                                Long resourceId, String details, long durationMs) {
        AuditLog entry = new AuditLog();
        entry.setUsername(currentUsername());
        entry.setCategory(category);
        entry.setAction(action);
        entry.setResourceType(resourceType);
        entry.setResourceId(resourceId);
        entry.setDetails(truncate(details, 1000));
        entry.setDurationMs(durationMs);
        entry.setTimestamp(LocalDateTime.now());

        // Extract HTTP request info when available
        try {
            ServletRequestAttributes attrs =
                    (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if (attrs != null) {
                HttpServletRequest req = attrs.getRequest();
                entry.setHttpMethod(req.getMethod());
                entry.setEndpoint(truncate(req.getRequestURI(), 500));
                entry.setIpAddress(getClientIp(req));
                entry.setUserAgent(truncate(req.getHeader("User-Agent"), 500));
            }
        } catch (Exception ignored) {
            // running outside of a web request context (e.g. tests)
        }
        return entry;
    }

    // ─── Read / query helpers (for admin dashboard) ──────────────────────

    public Page<AuditLog> findAll(Pageable pageable) {
        return repo.findAll(pageable);
    }

    public Page<AuditLog> findByUser(String username, Pageable pageable) {
        return repo.findByUsernameOrderByTimestampDesc(username, pageable);
    }

    public Page<AuditLog> findByCategory(String category, Pageable pageable) {
        return repo.findByCategoryOrderByTimestampDesc(category, pageable);
    }

    public Page<AuditLog> findByAction(String action, Pageable pageable) {
        return repo.findByActionOrderByTimestampDesc(action, pageable);
    }

    public Page<AuditLog> findByDateRange(LocalDateTime from, LocalDateTime to, Pageable pageable) {
        return repo.findByTimestampBetweenOrderByTimestampDesc(from, to, pageable);
    }

    public Page<AuditLog> findFailures(Pageable pageable) {
        return repo.findBySuccessFalseOrderByTimestampDesc(pageable);
    }

    /**
     * Returns a map of { category → count } for a specific user —
     * useful for understanding user interest.
     */
    public Map<String, Long> userInterestSummary(String username) {
        return repo.countByCategoryForUser(username).stream()
                .collect(Collectors.toMap(
                        row -> (String) row[0],
                        row -> (Long) row[1],
                        (a, b) -> a,
                        LinkedHashMap::new));
    }

    /**
     * Returns a map of { action → count } for a specific user.
     */
    public Map<String, Long> userActionSummary(String username) {
        return repo.countByActionForUser(username).stream()
                .collect(Collectors.toMap(
                        row -> (String) row[0],
                        row -> (Long) row[1],
                        (a, b) -> a,
                        LinkedHashMap::new));
    }

    /**
     * Returns top viewed products: list of { productId, viewCount }.
     */
    public List<Map<String, Object>> mostViewedProducts(int limit) {
        return repo.mostViewedProducts(PageRequest.of(0, limit)).stream()
                .map(row -> Map.<String, Object>of("productId", row[0], "views", row[1]))
                .collect(Collectors.toList());
    }

    /**
     * Returns top searched terms: list of { term, count }.
     */
    public List<Map<String, Object>> mostSearchedTerms(int limit) {
        return repo.mostSearchedTerms(PageRequest.of(0, limit)).stream()
                .map(row -> Map.<String, Object>of("term", row[0], "count", row[1]))
                .collect(Collectors.toList());
    }

    /**
     * Global category counts.
     */
    public Map<String, Long> categorySummary() {
        return repo.countByCategory().stream()
                .collect(Collectors.toMap(
                        row -> (String) row[0],
                        row -> (Long) row[1],
                        (a, b) -> a,
                        LinkedHashMap::new));
    }

    // ─── Utilities ───────────────────────────────────────────────────────

    private String currentUsername() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return (auth != null && auth.isAuthenticated() && !"anonymousUser".equals(auth.getPrincipal()))
                ? auth.getName() : "anonymous";
    }

    private String getClientIp(HttpServletRequest request) {
        String xff = request.getHeader("X-Forwarded-For");
        if (xff != null && !xff.isEmpty()) {
            return xff.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }

    private String truncate(String val, int maxLen) {
        if (val == null) return null;
        return val.length() > maxLen ? val.substring(0, maxLen) : val;
    }
}
