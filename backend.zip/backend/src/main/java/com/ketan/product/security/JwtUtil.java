package com.ketan.product.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Base64;
import java.util.Date;
import java.util.UUID;

@Component
public class JwtUtil {
    private final Key key;
    private final String issuer;
    private final String audience;

    public JwtUtil(@Value("${jwt.secret:}") String secret,
                   @Value("${jwt.issuer:shyamaju-backend}") String issuer,
                   @Value("${jwt.audience:shyamaju-frontend}") String audience) {
        this.issuer = issuer;
        this.audience = audience;

        if (secret != null && !secret.isBlank()) {
            // Decode Base64 secret for full entropy (32 bytes = 256 bits)
            byte[] decoded;
            try {
                decoded = Base64.getDecoder().decode(secret);
            } catch (IllegalArgumentException e) {
                // fallback: use raw bytes if not valid Base64
                decoded = secret.getBytes();
            }
            this.key = Keys.hmacShaKeyFor(decoded);
        } else {
            this.key = Keys.secretKeyFor(SignatureAlgorithm.HS256);
        }
    }

    /**
     * Generate a signed JWT with username, roles, issuer, audience, and a unique token ID (jti).
     * The HMAC-SHA256 signature ensures the payload CANNOT be tampered with —
     * any change to claims will invalidate the signature and be rejected by parseToken().
     */
    public String generateToken(String username, String roles, long validityMillis) {
        Date now = new Date();
        Date exp = new Date(now.getTime() + validityMillis);
        return Jwts.builder()
                .setId(UUID.randomUUID().toString())   // unique token id — prevents replay
                .setIssuer(issuer)                     // must match on verification
                .setAudience(audience)                 // must match on verification
                .setSubject(username)
                .claim("roles", roles)
                .setIssuedAt(now)
                .setExpiration(exp)
                .signWith(key, SignatureAlgorithm.HS256) // explicit algorithm — prevents "none" attack
                .compact();
    }

    /**
     * Parse and FULLY validate the JWT:
     *   1. Signature verification — rejects any tampered payload
     *   2. Expiration check — rejects expired tokens
     *   3. Issuer validation — rejects tokens from other systems
     *   4. Audience validation — rejects tokens not meant for this app
     *
     * If ANY check fails, an exception is thrown and the token is rejected.
     */
    public Claims parseToken(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(key)
                .requireIssuer(issuer)           // reject if iss doesn't match
                .requireAudience(audience)       // reject if aud doesn't match
                .build()
                .parseClaimsJws(token)           // validates signature + expiration
                .getBody();
    }
}
