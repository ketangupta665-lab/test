package com.ketan.product.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * In-memory OTP store.
 * Generates a 6-digit code, keeps it for 5 minutes, then expires.
 * The OTP is logged to the console so you can test without real SMS/email.
 */
@Service
public class OtpService {

    private static final Logger log = LoggerFactory.getLogger(OtpService.class);
    private static final long OTP_VALIDITY_SECONDS = 300; // 5 minutes
    private static final SecureRandom random = new SecureRandom();

    /** contact → (code, expiresAt) */
    private final Map<String, OtpEntry> store = new ConcurrentHashMap<>();

    private record OtpEntry(String code, Instant expiresAt) {}

    /**
     * Generate and store a 6-digit OTP for the given contact (email or phone).
     * Returns the code (also logged to console).
     */
    public String generateOtp(String contact) {
        String code = String.format("%06d", random.nextInt(1_000_000));
        Instant expiry = Instant.now().plusSeconds(OTP_VALIDITY_SECONDS);
        store.put(normalise(contact), new OtpEntry(code, expiry));
        log.info("===== OTP for {} : {} (expires {}) =====", contact, code, expiry);
        return code;
    }

    /**
     * Validate the supplied code against the stored OTP.
     * On success the entry is consumed (one-time use).
     */
    public boolean verifyOtp(String contact, String code) {
        if (contact == null || code == null) return false;
        OtpEntry entry = store.get(normalise(contact));
        if (entry == null) return false;
        if (Instant.now().isAfter(entry.expiresAt())) {
            store.remove(normalise(contact));
            return false;
        }
        if (entry.code().equals(code.trim())) {
            store.remove(normalise(contact)); // consume
            return true;
        }
        return false;
    }

    private static String normalise(String s) {
        return s == null ? "" : s.trim().toLowerCase();
    }
}
