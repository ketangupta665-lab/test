package com.ketan.product.service;

import com.ketan.product.exception.ResourceNotFoundException;
import com.ketan.product.model.Product;
import com.ketan.product.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import com.ketan.product.model.Product;

@Service
public class CatalogService {
    private final ProductRepository repo;

    public CatalogService(ProductRepository repo) { this.repo = repo; }

    // Public listing: only approved products
    public List<Product> list() { return repo.findByApprovedTrue(); }

    public Product get(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product", "id", id));
    }

    // Save product (new products are not approved by default)
    public Product save(Product p) { p.setApproved(false); return repo.save(p); }

    // Admin: list pending approval
    public List<Product> pending() { return repo.findByApprovedFalse(); }

    // Admin: approve product
    public Product approve(Long id) {
        return repo.findById(id).map(p -> { p.setApproved(true); return repo.save(p); })
                .orElseThrow(() -> new ResourceNotFoundException("Product", "id", id));
    }

    public Page<Product> search(String q, java.math.BigDecimal min, java.math.BigDecimal max, Pageable pageable, boolean fuzzy) {
        if (fuzzy && q != null && !q.isBlank()) {
            String[] tokens = q.toLowerCase().trim().split("\\s+");
            Specification<Product> spec = (root, query, cb) -> cb.isTrue(root.get("approved"));
            for (String t : tokens) {
                String like = "%" + t + "%";
                Specification<Product> tokenSpec = (root, query, cb) -> cb.or(
                        cb.like(cb.lower(root.get("name")), like),
                        cb.like(cb.lower(root.get("description")), like),
                        cb.like(cb.lower(root.get("sku")), like)
                );
                spec = spec.and(tokenSpec);
            }
            if (min != null) spec = spec.and((r, qy, cb) -> cb.ge(r.get("price"), min));
            if (max != null) spec = spec.and((r, qy, cb) -> cb.le(r.get("price"), max));
            return repo.findAll(spec, pageable);
        }
        // default search (non-fuzzy) uses JPQL method
        return repo.search((q == null || q.isBlank()) ? null : q, min, max, pageable);
    }

    // Inventory operations
    public Product setStock(Long id, int qty) {
        return repo.findById(id).map(p -> { p.setStock(qty); return repo.save(p); })
                .orElseThrow(() -> new ResourceNotFoundException("Product", "id", id));
    }

    public Product adjustStock(Long id, int delta) {
        return repo.findById(id).map(p -> {
            int newStock = Math.max(0, p.getStock() + delta);
            p.setStock(newStock);
            return repo.save(p);
        }).orElseThrow(() -> new ResourceNotFoundException("Product", "id", id));
    }

    public java.util.List<Product> inventory() { return repo.findAll(); }
}
