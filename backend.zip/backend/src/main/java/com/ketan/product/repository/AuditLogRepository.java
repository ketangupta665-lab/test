package com.ketan.product.repository;

import com.ketan.product.model.AuditLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {

    /** Find all logs for a specific user, most recent first. */
    Page<AuditLog> findByUsernameOrderByTimestampDesc(String username, Pageable pageable);

    /** Find logs by category (e.g. CATALOG_VIEW, CART, ORDER). */
    Page<AuditLog> findByCategoryOrderByTimestampDesc(String category, Pageable pageable);

    /** Find logs by action. */
    Page<AuditLog> findByActionOrderByTimestampDesc(String action, Pageable pageable);

    /** Find logs within a time range. */
    Page<AuditLog> findByTimestampBetweenOrderByTimestampDesc(LocalDateTime from, LocalDateTime to, Pageable pageable);

    /** Find logs for a user within a time range. */
    Page<AuditLog> findByUsernameAndTimestampBetweenOrderByTimestampDesc(
            String username, LocalDateTime from, LocalDateTime to, Pageable pageable);

    /** Count actions per category for a user – useful for interest analysis. */
    @Query("SELECT a.category, COUNT(a) FROM AuditLog a WHERE a.username = :username GROUP BY a.category ORDER BY COUNT(a) DESC")
    List<Object[]> countByCategoryForUser(@Param("username") String username);

    /** Count actions per action type for a user. */
    @Query("SELECT a.action, COUNT(a) FROM AuditLog a WHERE a.username = :username GROUP BY a.action ORDER BY COUNT(a) DESC")
    List<Object[]> countByActionForUser(@Param("username") String username);

    /** Most viewed products (by resourceId where category = PRODUCT_DETAIL). */
    @Query("SELECT a.resourceId, COUNT(a) FROM AuditLog a WHERE a.category = 'PRODUCT_DETAIL' AND a.resourceId IS NOT NULL GROUP BY a.resourceId ORDER BY COUNT(a) DESC")
    List<Object[]> mostViewedProducts(Pageable pageable);

    /** Most searched terms. */
    @Query("SELECT a.details, COUNT(a) FROM AuditLog a WHERE a.action = 'SEARCH_PRODUCTS' AND a.details IS NOT NULL GROUP BY a.details ORDER BY COUNT(a) DESC")
    List<Object[]> mostSearchedTerms(Pageable pageable);

    /** User interest breakdown – categories by user in a time range. */
    @Query("SELECT a.username, a.category, COUNT(a) FROM AuditLog a WHERE a.timestamp BETWEEN :from AND :to GROUP BY a.username, a.category ORDER BY a.username, COUNT(a) DESC")
    List<Object[]> userInterestBreakdown(@Param("from") LocalDateTime from, @Param("to") LocalDateTime to);

    /** Failed actions (security). */
    Page<AuditLog> findBySuccessFalseOrderByTimestampDesc(Pageable pageable);

    /** Count by category globally. */
    @Query("SELECT a.category, COUNT(a) FROM AuditLog a GROUP BY a.category ORDER BY COUNT(a) DESC")
    List<Object[]> countByCategory();
}
