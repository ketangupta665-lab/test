package com.ketan.product.controller;

import com.ketan.product.exception.BadRequestException;
import com.ketan.product.exception.ResourceNotFoundException;
import com.ketan.product.model.Coupon;
import com.ketan.product.repository.CouponRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;

@RestController
@RequestMapping("/api/coupons")
public class CouponController {

    private static final Set<String> VALID_TYPES = Set.of("PERCENTAGE", "FLAT_AMOUNT", "FREE_DELIVERY");
    private final CouponRepository couponRepo;

    public CouponController(CouponRepository couponRepo) {
        this.couponRepo = couponRepo;
    }

    // ─── Admin endpoints ───────────────────────────────────────────

    @GetMapping("/admin")
    @PreAuthorize("hasRole('ADMIN')")
    public List<Coupon> listAll() {
        return couponRepo.findAll();
    }

    @PostMapping("/admin")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Coupon> create(@RequestBody Coupon coupon) {
        if (coupon.getCode() == null || coupon.getCode().isBlank())
            throw new BadRequestException("Coupon code is required");
        coupon.setCode(coupon.getCode().toUpperCase().trim());
        if (couponRepo.existsByCodeIgnoreCase(coupon.getCode()))
            throw new BadRequestException("Coupon code already exists");
        if (coupon.getDiscountType() == null || !VALID_TYPES.contains(coupon.getDiscountType()))
            throw new BadRequestException("Discount type must be one of: PERCENTAGE, FLAT_AMOUNT, FREE_DELIVERY");
        if (coupon.getExpiryDate() == null)
            throw new BadRequestException("Expiry date is required");
        coupon.setUsedCount(0);
        coupon.setCreatedAt(LocalDateTime.now());
        return ResponseEntity.ok(couponRepo.save(coupon));
    }

    @PutMapping("/admin/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Coupon> update(@PathVariable Long id, @RequestBody Coupon updated) {
        Coupon existing = couponRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Coupon", "id", id));
        if (updated.getCode() != null && !updated.getCode().isBlank()) {
            String newCode = updated.getCode().toUpperCase().trim();
            if (!newCode.equals(existing.getCode()) && couponRepo.existsByCodeIgnoreCase(newCode))
                throw new BadRequestException("Coupon code already exists");
            existing.setCode(newCode);
        }
        if (updated.getDiscountType() != null) {
            if (!VALID_TYPES.contains(updated.getDiscountType()))
                throw new BadRequestException("Invalid discount type");
            existing.setDiscountType(updated.getDiscountType());
        }
        if (updated.getDiscountValue() != null) existing.setDiscountValue(updated.getDiscountValue());
        if (updated.getMinOrderAmount() != null) existing.setMinOrderAmount(updated.getMinOrderAmount());
        if (updated.getMaxDiscountAmount() != null) existing.setMaxDiscountAmount(updated.getMaxDiscountAmount());
        if (updated.getExpiryDate() != null) existing.setExpiryDate(updated.getExpiryDate());
        existing.setActive(updated.isActive());
        existing.setUsageLimit(updated.getUsageLimit());
        return ResponseEntity.ok(couponRepo.save(existing));
    }

    @DeleteMapping("/admin/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (!couponRepo.existsById(id))
            throw new ResourceNotFoundException("Coupon", "id", id);
        couponRepo.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    // ─── User endpoint: validate & calculate discount ──────────────

    @PostMapping("/apply")
    public ResponseEntity<?> applyCoupon(@RequestBody Map<String, Object> body) {
        String code = (String) body.get("code");
        BigDecimal subtotal = new BigDecimal(body.get("subtotal").toString());

        if (code == null || code.isBlank())
            throw new BadRequestException("Coupon code is required");

        Coupon coupon = couponRepo.findByCodeIgnoreCase(code.trim())
                .orElseThrow(() -> new BadRequestException("Invalid coupon code"));

        // Check active
        if (!coupon.isActive())
            throw new BadRequestException("This coupon is no longer active");

        // Check expiry
        if (coupon.getExpiryDate() != null && LocalDateTime.now().isAfter(coupon.getExpiryDate()))
            throw new BadRequestException("This coupon has expired");

        // Check usage limit
        if (coupon.getUsageLimit() > 0 && coupon.getUsedCount() >= coupon.getUsageLimit())
            throw new BadRequestException("This coupon has reached its usage limit");

        // Check minimum order amount
        if (coupon.getMinOrderAmount() != null && subtotal.compareTo(coupon.getMinOrderAmount()) < 0)
            throw new BadRequestException("Minimum order amount of ₹" + coupon.getMinOrderAmount().intValue() + " required");

        // Calculate discount
        BigDecimal discount = BigDecimal.ZERO;
        boolean freeDelivery = false;
        String description;

        switch (coupon.getDiscountType()) {
            case "PERCENTAGE":
                discount = subtotal.multiply(coupon.getDiscountValue()).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
                if (coupon.getMaxDiscountAmount() != null && discount.compareTo(coupon.getMaxDiscountAmount()) > 0)
                    discount = coupon.getMaxDiscountAmount();
                description = coupon.getDiscountValue().intValue() + "% off" +
                        (coupon.getMaxDiscountAmount() != null ? " (up to ₹" + coupon.getMaxDiscountAmount().intValue() + ")" : "");
                break;
            case "FLAT_AMOUNT":
                discount = coupon.getDiscountValue();
                if (discount.compareTo(subtotal) > 0) discount = subtotal;
                description = "₹" + coupon.getDiscountValue().intValue() + " off";
                break;
            case "FREE_DELIVERY":
                freeDelivery = true;
                description = "Free delivery";
                break;
            default:
                throw new BadRequestException("Unknown discount type");
        }

        return ResponseEntity.ok(Map.of(
                "valid", true,
                "code", coupon.getCode(),
                "discountType", coupon.getDiscountType(),
                "discount", discount,
                "freeDelivery", freeDelivery,
                "description", description
        ));
    }
}
