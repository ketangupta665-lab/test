package com.ketan.product.aspect;

import com.ketan.product.service.AuditLogService;
import jakarta.servlet.http.HttpServletRequest;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.lang.reflect.Parameter;

/**
 * Cross-cutting audit aspect – intercepts every REST controller method,
 * determines the category and action, and persists a detailed audit log
 * entry via {@link AuditLogService}.
 *
 * Categories are mapped by endpoint path so that user-interest analytics
 * can group views, searches, cart interactions, purchases, etc.
 */
@Aspect
@Component
public class AuditAspect {

    private static final Logger log = LoggerFactory.getLogger(AuditAspect.class);
    private final AuditLogService auditLogService;

    public AuditAspect(AuditLogService auditLogService) {
        this.auditLogService = auditLogService;
    }

    @Around("within(@org.springframework.web.bind.annotation.RestController *)")
    public Object auditController(ProceedingJoinPoint pjp) throws Throwable {
        long start = System.currentTimeMillis();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String user = (auth != null && auth.isAuthenticated() && !"anonymousUser".equals(auth.getPrincipal()))
                ? auth.getName() : "anonymous";

        // Resolve HTTP info
        String uri = "";
        String httpMethod = "";
        try {
            ServletRequestAttributes attrs =
                    (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if (attrs != null) {
                HttpServletRequest req = attrs.getRequest();
                uri = req.getRequestURI();
                httpMethod = req.getMethod();
            }
        } catch (Exception ignored) { }

        // Determine category + action + resource info
        String category = resolveCategory(uri);
        String action = resolveAction(uri, httpMethod, pjp);
        String resourceType = resolveResourceType(uri);
        Long resourceId = resolveResourceId(pjp, uri);
        String details = resolveDetails(pjp, uri);

        log.info("[AUDIT] user={} action={} category={} endpoint={} {}",
                user, action, category, httpMethod, uri);

        try {
            Object result = pjp.proceed();
            long duration = System.currentTimeMillis() - start;

            auditLogService.logAction(category, action, resourceType, resourceId, details, duration);

            log.info("[AUDIT] user={} completed={} duration={}ms", user, action, duration);
            return result;
        } catch (Throwable t) {
            long duration = System.currentTimeMillis() - start;

            auditLogService.logFailure(category, action, resourceType, resourceId,
                    details, t.getMessage(), duration);

            log.error("[AUDIT] user={} failed={} error={}", user, action, t.getMessage());
            throw t;
        }
    }

    // ─── Category mapping ────────────────────────────────────────────────

    private String resolveCategory(String uri) {
        if (uri.isEmpty()) return "UNKNOWN";

        if (uri.contains("/api/auth/otp"))       return "OTP";
        if (uri.contains("/api/auth/oauth"))      return "OAUTH";
        if (uri.contains("/api/auth"))            return "AUTH";
        if (uri.contains("/api/catalog/search"))  return "CATALOG_SEARCH";
        if (uri.matches(".*/api/catalog/\\d+/availability")) return "PRODUCT_AVAILABILITY";
        if (uri.matches(".*/api/catalog/\\d+/stock.*"))      return "INVENTORY";
        if (uri.matches(".*/api/catalog/\\d+/approve"))      return "ADMIN_CATALOG";
        if (uri.matches(".*/api/catalog/\\d+$"))  return "PRODUCT_DETAIL";
        if (uri.contains("/api/catalog/pending")) return "ADMIN_CATALOG";
        if (uri.contains("/api/catalog"))         return "CATALOG_VIEW";
        if (uri.contains("/api/cart/checkout"))   return "CHECKOUT";
        if (uri.contains("/api/cart"))            return "CART";
        if (uri.contains("/api/orders/mine"))     return "ORDER";
        if (uri.contains("/api/orders"))          return "ORDER";
        if (uri.contains("/api/payments/verify")) return "PAYMENT_VERIFY";
        if (uri.contains("/api/payments/create")) return "PAYMENT";
        if (uri.contains("/api/payments"))        return "PAYMENT";
        if (uri.contains("/api/invoices"))        return "INVOICE";
        if (uri.contains("/api/addresses"))       return "ADDRESS";
        if (uri.contains("/api/users/me"))        return "PROFILE";
        if (uri.contains("/api/users/register"))  return "REGISTRATION";
        if (uri.contains("/api/users"))           return "USER_MGMT";
        if (uri.contains("/api/admin"))           return "ADMIN";

        return "OTHER";
    }

    // ─── Action mapping ──────────────────────────────────────────────────

    private String resolveAction(String uri, String httpMethod, ProceedingJoinPoint pjp) {
        // Auth
        if (uri.endsWith("/api/auth/login"))        return "LOGIN";
        if (uri.endsWith("/api/auth/logout"))        return "LOGOUT";
        if (uri.endsWith("/api/auth/refresh"))       return "TOKEN_REFRESH";
        if (uri.endsWith("/api/auth/token-config"))  return "TOKEN_CONFIG";

        // OTP
        if (uri.endsWith("/otp/request"))           return "OTP_REQUEST";
        if (uri.endsWith("/otp/verify"))            return "OTP_VERIFY";

        // OAuth
        if (uri.contains("/oauth/google/callback")) return "GOOGLE_OAUTH_CALLBACK";
        if (uri.contains("/oauth/google"))          return "GOOGLE_OAUTH_REDIRECT";

        // Catalog
        if (uri.contains("/catalog/search"))        return "SEARCH_PRODUCTS";
        if (uri.matches(".*/catalog/\\d+/availability")) return "CHECK_AVAILABILITY";
        if (uri.matches(".*/catalog/\\d+/stock/adjust")) return "ADJUST_STOCK";
        if (uri.matches(".*/catalog/\\d+/stock"))   return "SET_STOCK";
        if (uri.matches(".*/catalog/\\d+/approve")) return "APPROVE_PRODUCT";
        if (uri.contains("/catalog/pending"))       return "VIEW_PENDING_PRODUCTS";
        if (uri.matches(".*/catalog/\\d+$"))        return "VIEW_PRODUCT_DETAIL";
        if (uri.endsWith("/api/catalog") && "POST".equals(httpMethod)) return "CREATE_PRODUCT";
        if (uri.endsWith("/api/catalog"))           return "VIEW_PRODUCTS";

        // Cart
        if (uri.contains("/cart/checkout"))         return "CHECKOUT";
        if (uri.contains("/cart/add"))              return "ADD_TO_CART";
        if (uri.contains("/cart/update"))           return "UPDATE_CART_ITEM";
        if (uri.contains("/cart/remove"))           return "REMOVE_FROM_CART";
        if (uri.endsWith("/api/cart"))              return "VIEW_CART";

        // Orders
        if (uri.endsWith("/orders/mine") && "POST".equals(httpMethod)) return "CREATE_ORDER";
        if (uri.endsWith("/orders/mine"))           return "VIEW_MY_ORDERS";
        if (uri.matches(".*/orders/\\d+$"))         return "VIEW_ORDER_DETAIL";
        if (uri.endsWith("/api/orders") && "POST".equals(httpMethod)) return "CREATE_ORDER";
        if (uri.endsWith("/api/orders"))            return "VIEW_ALL_ORDERS";

        // Payments
        if (uri.contains("/payments/verify"))       return "VERIFY_PAYMENT";
        if (uri.contains("/payments/create-order")) return "CREATE_PAYMENT_ORDER";
        if (uri.contains("/payments/razorpay-key")) return "GET_PAYMENT_KEY";
        if (uri.matches(".*/payments/order/\\d+"))  return "VIEW_PAYMENT_STATUS";
        if (uri.matches(".*/payments/\\d+$"))       return "VIEW_PAYMENT_DETAIL";
        if (uri.endsWith("/api/payments"))          return "VIEW_ALL_PAYMENTS";

        // Invoices
        if (uri.matches(".*/invoices/\\d+$"))       return "VIEW_INVOICE_DETAIL";
        if (uri.endsWith("/api/invoices") && "POST".equals(httpMethod)) return "CREATE_INVOICE";
        if (uri.endsWith("/api/invoices"))          return "VIEW_ALL_INVOICES";

        // Addresses
        if (uri.matches(".*/addresses/\\d+$") && "DELETE".equals(httpMethod)) return "DELETE_ADDRESS";
        if (uri.endsWith("/api/addresses") && "POST".equals(httpMethod)) return "ADD_ADDRESS";
        if (uri.endsWith("/api/addresses"))         return "VIEW_ADDRESSES";

        // Users / Profile
        if (uri.endsWith("/users/me"))              return "VIEW_PROFILE";
        if (uri.endsWith("/users/register"))        return "REGISTER";
        if (uri.matches(".*/users/\\d+$"))          return "VIEW_USER_DETAIL";
        if (uri.endsWith("/api/users"))             return "VIEW_ALL_USERS";

        // Admin
        if (uri.contains("/admin/orders") && uri.contains("/payment-status")) return "ADMIN_UPDATE_PAYMENT_STATUS";
        if (uri.contains("/admin/orders") && uri.contains("/shipment"))       return "ADMIN_UPDATE_SHIPMENT";
        if (uri.contains("/admin/orders") && uri.contains("/refund"))         return "ADMIN_REFUND_ORDER";
        if (uri.contains("/admin/orders"))          return "ADMIN_VIEW_ORDERS";
        if (uri.contains("/admin/invoices") && uri.contains("/detail")) return "ADMIN_VIEW_INVOICE_DETAIL";
        if (uri.contains("/admin/invoices"))        return "ADMIN_VIEW_INVOICES";
        if (uri.contains("/admin/payments"))        return "ADMIN_VIEW_PAYMENTS";
        if (uri.contains("/admin/products") && uri.contains("/stock/adjust")) return "ADMIN_ADJUST_STOCK";
        if (uri.contains("/admin/products") && uri.contains("/stock"))        return "ADMIN_SET_STOCK";
        if (uri.endsWith("/admin/products"))        return "ADMIN_CREATE_PRODUCT";
        if (uri.contains("/admin/inventory"))       return "ADMIN_VIEW_INVENTORY";

        // fallback: use method name
        return pjp.getSignature().getName().toUpperCase();
    }

    // ─── Resource type ───────────────────────────────────────────────────

    private String resolveResourceType(String uri) {
        if (uri.contains("/catalog") || uri.contains("/products")) return "Product";
        if (uri.contains("/orders"))    return "Order";
        if (uri.contains("/payments"))  return "Payment";
        if (uri.contains("/invoices"))  return "Invoice";
        if (uri.contains("/cart"))      return "Cart";
        if (uri.contains("/addresses")) return "Address";
        if (uri.contains("/users"))     return "User";
        return null;
    }

    // ─── Extract numeric resource id from path or arguments ──────────────

    private Long resolveResourceId(ProceedingJoinPoint pjp, String uri) {
        // Try to extract from @PathVariable named "id" or "orderId"
        try {
            MethodSignature sig = (MethodSignature) pjp.getSignature();
            Parameter[] params = sig.getMethod().getParameters();
            Object[] args = pjp.getArgs();
            for (int i = 0; i < params.length; i++) {
                PathVariable pv = params[i].getAnnotation(PathVariable.class);
                if (pv != null && args[i] instanceof Long) {
                    return (Long) args[i];
                }
            }
        } catch (Exception ignored) { }

        // Fallback: extract last numeric segment from URI
        try {
            String[] segments = uri.split("/");
            for (int i = segments.length - 1; i >= 0; i--) {
                if (segments[i].matches("\\d+")) {
                    return Long.parseLong(segments[i]);
                }
            }
        } catch (Exception ignored) { }

        return null;
    }

    // ─── Build extra details for interest tracking ───────────────────────

    private String resolveDetails(ProceedingJoinPoint pjp, String uri) {
        try {
            MethodSignature sig = (MethodSignature) pjp.getSignature();
            Parameter[] params = sig.getMethod().getParameters();
            Object[] args = pjp.getArgs();

            // Capture search query
            if (uri.contains("/search")) {
                for (int i = 0; i < params.length; i++) {
                    RequestParam rp = params[i].getAnnotation(RequestParam.class);
                    if (rp != null && "q".equals(rp.value()) && args[i] != null) {
                        return "query=" + args[i];
                    }
                    // also check parameter name
                    if ("q".equals(params[i].getName()) && args[i] != null) {
                        return "query=" + args[i];
                    }
                }
            }

            // Capture productId for cart add
            if (uri.contains("/cart/add")) {
                for (int i = 0; i < params.length; i++) {
                    RequestParam rp = params[i].getAnnotation(RequestParam.class);
                    if (rp != null && "productId".equals(rp.value()) && args[i] != null) {
                        return "productId=" + args[i];
                    }
                }
            }

            // Capture qty for stock changes
            if (uri.contains("/stock")) {
                for (int i = 0; i < params.length; i++) {
                    RequestParam rp = params[i].getAnnotation(RequestParam.class);
                    if (rp != null && ("qty".equals(rp.value()) || "delta".equals(rp.value())) && args[i] != null) {
                        return rp.value() + "=" + args[i];
                    }
                }
            }
        } catch (Exception ignored) { }

        return null;
    }
}
